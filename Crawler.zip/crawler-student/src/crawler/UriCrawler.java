/*
 * Copyright 2017 Marc Liberatore.
 */

package crawler;

import java.net.URI;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;

import org.jsoup.nodes.Document;

import document.RetrievedDocument;

/**
 * A simplified web crawler, specialized to crawl local URIs rather
 * than to retrieve remote documents.
 * 
 * @author liberato
 *
 */
public class UriCrawler {
	
	// Document class that contains URI, some texts, and a list of links
	Set<RetrievedDocument> retrieved;
	
	// URI class that can be associated with RetrievedDocument
	Set<URI> URIbucket;
	
	// A set of URI that have been visited(successfully or not)
	Set<URI> URIvisited;
	
	// A set of URI that have been successfully visited.
	//Set<URI> successfullyVisited;
	
	// Max number of documents our crawler will ever visit.
	int visitQuota;
	
	// Keep track of our visit capacity.
	int visitCount;

	/**
	 * Instantiates a new UriCrawler. The maximum number of documents a crawler
	 * will attempt to visit, ever, is limited to visitQuota.
	 * 
	 * @param visitQuota
	 *            the maximum number of documents a crawler will attempt to
	 *            visit
	 * @throws IllegalArgumentException
	 *             if maximumRetrievalAttempts is less than one
	 */
	public UriCrawler(int visitQuota) throws IllegalArgumentException {
		
		if (visitQuota < 1) {
			
			throw new IllegalArgumentException();
		}
		
		this.visitQuota = visitQuota;
		this.visitCount = 0;
		
		this.retrieved = new HashSet<>();
		this.URIbucket = new HashSet<>();
		this.URIvisited = new HashSet<>();
		//this.successfullyVisited = new HashSet<>();
	}

	/**
	 * Returns the set of URIs that this crawler has attempted to visit
	 * (successfully or not).
	 * 
	 * @return the set of URIs that this crawler has attempted to visit
	 */
	public Set<URI> getVistedUris() {
		
		return new HashSet<>(this.URIvisited);
	}
	
	/**
	 * Returns the set of RetrievedDocuments corresponding to the URIs
	 * this crawler has successfully visited.
	 * 
	 * @return the set of RetrievedDocuments corresponding to the URIs
	 * this crawler has successfully visited
	 */
	public Set<RetrievedDocument> getVisitedDocuments() {
		
		return new HashSet<>(this.retrieved);
	}

	/**
	 * Adds a URI to the collections of URIs that this crawler should attempt to
	 * visit. Does not visit the URI.
	 * 
	 * @param uri
	 *            the URI to be visited (later!)
	 */
	public void addUri(URI uri) {
		
		this.URIbucket.add(uri);
	}
	
	public boolean maxVisit() {
		
		return this.visitCount == this.visitQuota;
	}

	/**
	 * Attempts to visit a single as-yet unattempted URI in this crawler's
	 * collection of to-be-visited URIs.
	 * 
	 * Visiting a document entails parsing the text and links from the URI.
	 * 
	 * If the parse succeeds:
	 * 
	 * - The "file:" links should be added to this crawler's collection of
	 * to-be-visited URIs.
	 * 
	 * - A new RetrievedDocument should be added to this crawler's collection of
	 * successfully visited documents.
	 * 
	 * If the parse fails, this method considers the visit attempted but
	 * unsuccessful.
	 * 
	 * @throws MaximumVisitsExceededException
	 *             if this crawler has already attempted to visit its quota of
	 *             visits
	 * @throws NoUnvisitedUrisException
	 *             if no more unattempted URI remain in this crawler's
	 *             collection of URIs to visit
	 */
	public void visitOne() throws MaximumVisitsExceededException, NoUnvisitedUrisException {
		
		// The crawler state has reached it's max visit capacity
		if (this.maxVisit()) {
			
			throw new MaximumVisitsExceededException();
		}
		
		/*
		 * The URI bucket holds unattempted URIs. When we attempt to
		 * visit them, they must be removed from the bucket and put
		 * into the visited collection. So, when the bucket is empty,
		 * we can be sure that there are no more URIs to visit. This
		 * assumes we did not already reach maximum visit quotas.
		 */
		if (this.URIbucket.isEmpty()) {
			
			throw new NoUnvisitedUrisException();
		}
		
		// After these two conditions, we have NOT reached maximum visits,
		// and we STILL have unattempted URI's.
		
		// First step is we need to get a URI from the bucket, removing it.
		// Add the URI to the visited.
		
		int count = 0;
		URI uri = null;
		Document d = null;
		
		// Get a URI from the set using iterable interface
		for (URI item : this.URIbucket) {
			
			// Only remove one URI
			if (count == 0) {
				
				this.URIbucket.remove(item);
				
				// Store the URI into the visited set, regardless if they will eventually fail.
				this.URIvisited.add(item);
				this.visitCount++;
		
				// Remember the URI that was removed
				uri = item;
			}
			
			break;
			
			//count++;
		}
		
		// Parse the URI
		d = CrawlerUtils.parse(uri);
		RetrievedDocument rd = null;
		
		// If the parse did not fail, then initialize the RetrievedDocument object to indicate success.
		// If the parse failed, then the URI is not used to initialize a RetrievalDocument Object.
		if (d != null) {
		
			// Instantiate a RetrievedDocument using the uri, texts, and list of links.
			rd = new RetrievedDocument(uri, d.text(), CrawlerUtils.getFileUriLinks(d));
			this.retrieved.add(rd);
			
			if (!CrawlerUtils.getFileUriLinks(d).isEmpty())
			
				// Add the to-be-visited links to the bucket of URIs
				for (URI item : CrawlerUtils.getFileUriLinks(d)) {
					
					this.URIbucket.add(item);
				}
		}
	}

	/**
	 * Attempts to visit all URIs in this crawler (and any URIs they reference,
	 * and so on).
	 * 
	 * This method will not raise a MaximumVisitsExceededException if there are
	 * more URIs than can be visited. It will instead stop once the UriCrawler's
	 * quota has been reached.
	 */
	public void visitAll() {
		
		// Boolean to control the while loop
		boolean greenLight = true;
		
		while (greenLight) {
			
			try {
				
				// Visit one URI
				this.visitOne();
				
			// If visitOne throws an exception, do not raise the exception here, but end the while loop
			} catch (MaximumVisitsExceededException e) {
				
				greenLight = false;
				
			// If visitOne throws an exception, do not raise the exception here, but end the while loop
			} catch (NoUnvisitedUrisException e) {
				
				greenLight = false;
			}
		}
	}
}
