/*
 * Copyright 2017 Marc Liberatore.
 */

package similarity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import sets.SetUtilities;

public class SimilarityUtilities {
	/**
	 * Returns the set of non-empty lines contained in a text, trimmed of
	 * leading and trailing whitespace.
	 * 
	 * @param text
	 * @return the trimmed set of lines
	 */
	
	/*
	 * text = "   You  \n  Shall \n Not  \n  Pass   "
	 * 
	 * Set<String> = {You, Shall, Not, Pass}
	 */
	public static Set<String> trimmedLines(String text) {
		
		//an empty set
		Set<String> stringSet = new HashSet<>();
		
		//if the text is empty, return an empty set
		if (text.isEmpty()) {
			
			return stringSet;
		}
		
		//splits the text based on newlines
		String[] array = text.split("\\n");
		
		//adds the split strings to the set
		for (int i = 0; i < array.length; i++) {
			
			//trim the leading whitespaces and ending whitespaces
			//this will take care of " \n    \n " issues
			array[i] = array[i].trim();
			
			//if the string is empty, do not add to the set
			if (!array[i].isEmpty()) {
				
				//add to the set
				stringSet.add(array[i]);
			}
		}
		
		return stringSet;
	}

	/**
	 * Returns a list of words in the text, in the order they appeared in the text, 
	 * converted to lowercase.
	 * 
	 * Words are defined as a contiguous sequence of letters and numbers.
	 *
	 * @param text
	 * @return a list of lowercase words
	 */
	public static List<String> asLowercaseWords(String text) {
		
		//create an empty list of strings
		List<String> list = new ArrayList<>();
		
		//if the string is empty
		if (text.isEmpty()) {
			
			return list;
		}
		
		//split the words based on non word-stuff
		String[] arrayWords = text.split("\\W+");
		
		//loop through our array of Strings
		for (int i = 0; i < arrayWords.length; i++) {
			
			//check if any of the arrayWords happen to be empty
			if (!arrayWords[i].isEmpty()) {
				
				//convert the words to lower case
				arrayWords[i] = arrayWords[i].toLowerCase();
				
				//add them to the list of Strings
				list.add(arrayWords[i]);
			}
		}
		
		return list;
	}

	/**
	 * Returns the line-based similarity of two texts.
	 * 
	 * The line-based similarity is the Jaccard index between each text's line
	 * set.
	 * 
	 * A text's line set is the set of trimmed lines in that text, as defined by
	 * trimmedLines.
	 * 
	 * @param text1
	 *            a text
	 * @param text2
	 *            another text
	 * @return
	 */
	public static double lineSimilarity(String text1, String text2) {
		
		//check if both strings are empty
		if (text1.isEmpty() && text2.isEmpty()) {
			
			return 1;
		}
		
		//send both strings to trimmedlines to be converted into a set
		Set<String> s1 = trimmedLines(text1);
		Set<String> s2 = trimmedLines(text2);
		
		//send both sets to jaccardIndex for a similarity evaluation
		//jaccardIndex is a static method, meaning it is visible to this class too
		//returns the double value of jaccardIndex
		return (SetUtilities.jaccardIndex(s1, s2));
	}

	/**
	 * Returns the line-based similarity of two texts.
	 * 
	 * The line-based similarity is the Jaccard index between each text's line
	 * set.
	 * 
	 * A text's line set is the set of trimmed lines in that text, as defined by
	 * trimmedLines, less the set of trimmed lines from the templateText. Removes
	 * the template text from consideration after trimming lines, not before.
	 * 
	 * @param text1
	 *            a text
	 * @param text2
	 *            another text
	 * @param templateText
	 *            a template, representing things the two texts have in common
	 * @return
	 */
	
	//converts both text to sets, uses set difference to remove the template elements
	//from both sets. Then calls jaccardIndex on the two sets.
	public static double lineSimilarity(String text1, String text2, String templateText) {
		
		//convert the two texts into sets that are trimmed of all leading and trailing whitespaces/newlines
		Set<String> s1 = trimmedLines(text1);
		Set<String> s2 = trimmedLines(text2);
		
		//check if the template is empty
		if (templateText.isEmpty()) {
			
			return (SetUtilities.jaccardIndex(s1, s2));
		}
		
		//convert the template to a set
		Set<String> t = trimmedLines(templateText);
		
		//use set difference to remove all the elements of template from both text sets
		s1 = SetUtilities.setDifference(s1, t);
		s2 = SetUtilities.setDifference(s2, t);
		
		//return the jaccardIndex of the two texts
		return (SetUtilities.jaccardIndex(s1, s2));
	}

	/**
	 * Returns a set of strings representing the shingling of the given length
	 * of a list of words.
	 * 
	 * A shingling of length k of a list of words is the set of all k-shingles
	 * of that list.
	 * 
	 * A k-shingle is the concatenation of k adjacent words.
	 * 
	 * For example, a 3-shingle of the list: ["a" "very" "fine" "young" "man"
	 * "I" "know"] is the set: {"averyfine" "veryfineyoung" "fineyoungman"
	 * "youngmanI" "manIknow"}.
	 * 
	 * @param words
	 * @param shingleLength
	 * @return 
	 */
	
	//length of k-shingle is the concatenation of k adjacent words
	//a shingle will be a concatenation of length words
	//these shingles will be stored in a set
	public static Set<String> shingle(List<String> words, int shingleLength) {
		
		Set<String> s = new HashSet<>();
		String setUp = "";
		
		//if the list is empty
		if (words.isEmpty()) {
			
			//return an empty set
			return s;
		}
		
		//if our shingle length is 1, then we just need to return the original list as a set
		if (shingleLength == 1) {
			
			//loop through the list of words
			for (int i = 0; i < words.size(); i++) {
				
				//add each element in the list to the set
				s.add(words.get(i));
			}
			
			//return the set
			return s;
		}
		
		
		//outer loop controls the starting point, as well as limiting the starting index so that 
		//all the k-shingle are of length shingleLength
		for(int initial = 0; initial <= words.size() - shingleLength; initial++) {
		
			//inner loop controls how many elements to concatenate based on shingleLength
			for(int advance = initial + 1; advance < shingleLength + initial; advance++) {
				
				//first time we are concatenating the starting and starting + 1 string in the list
				if (advance == initial + 1) {
					
					//store that in a string variable
					setUp = words.get(initial).concat(words.get(advance));
				}
				
				//once the first round has passed, concatenate to string variable
				else {
					
					//setUp is storing the new longer string after each concat
					setUp = setUp.concat(words.get(advance));
				}
			}
			
			//once we have hit shingleLength, must store it in the set
			s.add(setUp);
			
			//clear the setUp string so that it can be reused
			setUp = "";
		}
		
		return s;
	}

	/**
	 * Returns the shingled word similarity of two texts.
	 * 
	 * The shingled word similarity is the Jaccard index between each text's
	 * shingle set.
	 * 
	 * A text's shingle set is the set of shingles (of the given length) for the
	 * entire text, as defined by shingle and asLowercaseWords, 
	 * less the shingle set of the templateText. Removes the templateText 
	 * from consideration after shingling, not before.
	 * 
	 * @param text1
	 * @param text2
	 * @param templateText
	 * @param shingleLength
	 * @return
	 */
	
	/*
	 * 1. Shingle each text and template according to shingleLength
	 * 2. Do set difference for both text1 and text2 on templateText
	 * 3. Find the jaccard Index of text1 and text2
	 */
	public static double shingleSimilarity(String text1, String text2, String templateText, int shingleLength) {
		
		//convert a lengthy text1 and text2 into a list of words
		List<String> list1 = asLowercaseWords(text1);
		List<String> list2 = asLowercaseWords(text2);
		
		//convert the template into a list of words, if the templateText is empty, we should be returned an empty list
		List<String> listTemplate = asLowercaseWords(templateText);
		
		//store the k-shingles in a set after calling the shingle method
		Set<String> s1 = shingle(list1, shingleLength);
		Set<String> s2 = shingle(list2, shingleLength);
		
		//shingle the templateText list too, if the list is empty we should be returned an empty set
		Set<String> setTemplate = shingle(listTemplate, shingleLength);
		
		//find the set difference of both sets compared to the template set
		s1 = SetUtilities.setDifference(s1, setTemplate);
		s2 = SetUtilities.setDifference(s2, setTemplate);
				
		//return the jaccardIndex of the two sets
		return (SetUtilities.jaccardIndex(s1, s2));
	}
}
