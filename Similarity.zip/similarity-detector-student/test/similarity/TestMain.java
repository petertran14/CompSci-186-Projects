package similarity;

import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class TestMain {
	
	public static void main(String[] args) {
		
//		String simple = "Apple  \n   Banana  \n Clementine Durian\n";
//		
//		String[] string = simple.split("\\n");
//		
//		for (int i = 0; i < string.length; i++) {
//			
//			string[i] = string[i].trim();
//			System.out.println(string[i]);
//		}
//		
//		//numbers inside the double parathenses count as Strings
//		
//		String numbers = "happy 49 birthday";
//		
//		String[] foo = numbers.split("\\W+");
//		
//		for (String item : foo) {
//			
//			System.out.println(item);
//		}
		
		String lessSimple = "\nApple  \n \n  Banana  \n\n Clementine Durian\n";
		String simple = "Apple  \n   Banana  \n Clementine Durian\n";
		String blank = "   ";
		String toClear = "Nonsense";
		
		List<String> list = new ArrayList<>();
		list.add("a");
		list.add("very");
		list.add("fine");
		list.add("young");
		list.add("man");
		list.add("I");
		list.add("know");
		
		for (String item : list) {
			
			System.out.println(item);
		}
		
		Set<String> s = SimilarityUtilities.shingle(list, 3);
		
		for (String item : s) {
			
			System.out.println(item);
		}
		
//		System.out.println("Length " + blank.length());
//		blank = blank.trim();
//		System.out.println("Length " + blank.length());
//		
//		if (blank.isEmpty()) {
//			
//			System.out.println("Yay");
//		}
//		
//		else {
//			
//			System.out.println("Nay");
//		}
	
//		SimilarityUtilities foo = new SimilarityUtilities();
//		
//		Set<String> s1 = foo.trimmedLines(simple);
//		Set<String> s2 = foo.trimmedLines(lessSimple);
//		
//		System.out.println("Simple");
//		
//		for (String item : s1) {
//			
//			System.out.println(item);
//		}
//		
//		System.out.println("Less Simple");
//		
//		for (String item : s2) {
//			
//			System.out.println(item);
//		}
		
//		System.out.println(toClear);
//		
//		System.out.println(toClear.length());
//		
//		toClear = "";
//		
//		System.out.println(toClear);
//		System.out.println(toClear.length());
//		
//		if (toClear.isEmpty()) {
//			
//			System.out.println("Empty");
//		}
//		
//		else {
//			
//			System.out.println("Not");
//		}
	}

}
