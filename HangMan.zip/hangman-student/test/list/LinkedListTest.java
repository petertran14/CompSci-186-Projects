/*
 * Copyright 2017 Marc Liberatore.
 */

package list;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;


import list.LinkedList;

public class LinkedListTest {
	//@Rule
	//public Timeout globalTimeout = Timeout.seconds(10); // 10 seconds

	@Test
	public void testEmpty() {
		LinkedList<Integer> ll = new LinkedList<>();
		assertEquals(0, ll.size());
	}

	@Test
	public void testNotEmpty() {
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(10);
		assertEquals(1, ll.size());
	}
	
	@Test
	public void testTwo() {
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(10);
		ll.append(10);
		assertEquals(2, ll.size());
	}
	
	@Test
	public void testContains() {
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		assertTrue(ll.contains(20));
		assertTrue(ll.contains(10));
	}
	
	@Test
	public void testNotContains() {
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		assertFalse(ll.contains(1));
	}
	
	@Test 
	public void testCorrectValue() {
		
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		
		// The LinkedList is parameterized with Integer, so we must match that to prevent ambiguity.
		Integer zero = 0;
		Integer ten = 10;
		Integer twenty = 20;
		
		assertEquals(zero, ll.get(0));
		assertEquals(ten, ll.get(1));
		assertEquals(twenty, ll.get(2));
		assertEquals(zero, ll.getHead());
		assertEquals(twenty, ll.getTail());
	}
	
	@Test
	public void testCorrectFrontRemoval() {
		
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		
		Integer value = ll.remove(0);
		
		Integer zero = 0;
		Integer ten = 10;
		Integer twenty = 20;
		
		assertEquals(ten, ll.get(0));
		assertEquals(twenty, ll.get(1));
		assertEquals(2, ll.size());
		assertEquals(zero, value);
		assertEquals(ten, ll.getHead());
		assertEquals(twenty, ll.getTail());
	}
	
	@Test
	public void testCorrectMidRemoval() {
		
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		
		Integer value = ll.remove(1);
		
		// The LinkedList is parameterized with Integer, so we must match that to prevent ambiguity.
		Integer zero = 0;
		Integer ten = 10;
		Integer twenty = 20;
		
		assertEquals(zero, ll.get(0));
		assertEquals(twenty, ll.get(1));
		assertEquals(2, ll.size());
		assertEquals(ten, value);
		assertEquals(zero, ll.getHead());
		assertEquals(twenty, ll.getTail());
	}
	
	@Test
	public void testCorrectEndRemoval() {
		
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		
		Integer value = ll.remove(2);
		
		// The LinkedList is parameterized with Integer, so we must match that to prevent ambiguity.
		Integer zero = 0;
		Integer ten = 10;
		Integer twenty = 20;
		
		assertEquals(zero, ll.get(0));
		assertEquals(ten, ll.get(1));
		assertEquals(2, ll.size());
		assertEquals(twenty, value);
		assertEquals(zero, ll.getHead());
		assertEquals(ten, ll.getTail());
	}
	
	@Test
	public void testCorrectFrontSet() {
		
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		
		Integer value = ll.set(0, 20);
		
		// The LinkedList is parameterized with Integer, so we must match that to prevent ambiguity.
		Integer zero = 0;
		Integer ten = 10;
		Integer twenty = 20;
		
		assertEquals(twenty, ll.get(0));
		assertEquals(ten, ll.get(1));
		assertEquals(twenty, ll.get(2));
		
		assertEquals(3, ll.size());
		assertEquals(zero, value);
		assertEquals(twenty, ll.getHead());
		assertEquals(twenty, ll.getTail());
	}
	
	@Test
	public void testCorrectMidSet() {
		
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		
		Integer value = ll.set(1, 20);
		
		// The LinkedList is parameterized with Integer, so we must match that to prevent ambiguity.
		Integer zero = 0;
		Integer ten = 10;
		Integer twenty = 20;
		
		assertEquals(zero, ll.get(0));
		assertEquals(twenty, ll.get(1));
		assertEquals(twenty, ll.get(2));
		
		assertEquals(3, ll.size());
		assertEquals(ten, value);
		assertEquals(zero, ll.getHead());
		assertEquals(twenty, ll.getTail());
	}
	
	@Test
	public void testCorrectEndSet() {
		
		LinkedList<Integer> ll = new LinkedList<>();
		ll.append(0);
		ll.append(10);
		ll.append(20);
		
		Integer value = ll.set(2, 10);
		
		// The LinkedList is parameterized with Integer, so we must match that to prevent ambiguity.
		Integer zero = 0;
		Integer ten = 10;
		Integer twenty = 20;
		
		assertEquals(zero, ll.get(0));
		assertEquals(ten, ll.get(1));
		assertEquals(ten, ll.get(2));
		
		assertEquals(3, ll.size());
		assertEquals(twenty, value);
		assertEquals(zero, ll.getHead());
		assertEquals(ten, ll.getTail());
	}
}
