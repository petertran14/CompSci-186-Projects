package hangman;

import list.LinkedList;
import hangman.LinkedListGameModel;

public class Driver {

	public static void main(String[] args) {
		
//		LinkedList<Character> l = new LinkedList<>();
//		
//		for (int i = 0; i < 4; i++) {
//			
//			l.append('_');
//			
//			if (i != 3) { 
//			
//				l.append(' ');
//			}
//		}
//		
//		for (int i = 0; i < l.size(); i++) {
//			
//			System.out.print(l.get(i));
//		}
//		
//		System.out.println("foo");
		
//		LinkedList<Character> list = new LinkedList<>();
//		
//		list.append('a');
//		list.append('b');
//		list.append('c');
//		list.append('d');
		
//		list.display();
//		list.set(1, 4);
//		System.out.println();
//		list.display();
		
//		String display = "";
//		
//		display = display.concat("[");
//		
//		for (int i = 0; i < list.size(); i++) {
//			
//			display = display.concat(list.get(i).toString());
//			
//			if (i != list.size() - 1) {
//				
//				display = display.concat(", ");
//			}
//		}
//		
//		display = display.concat("]");
//		
//		System.out.println(display);
//		
//		String empty = "";
//		
//		LinkedList<Character> list2 = new LinkedList<>();
//		
//		list2.append('_');
//		list2.append('_');
//		list2.append('_');
//		list2.append('_');
//		
//		for (int i = 0; i < list2.size(); i++) {
//			
//			empty = empty.concat(list2.get(i).toString());
//			
//			if (i != list2.size() - 1) {
//				
//				empty = empty.concat(" ");
//			}
//		}
//		
//		System.out.println(empty);
		
		LinkedListGameModel list = new LinkedListGameModel("Zigzag");
		
	}	
}
