/*
 * Copyright 2017 Marc Liberatore.
 */

package hangman;

import list.LinkedList;

public class LinkedListGameModel implements GameModel {
	
	// The word that the player is trying to guess.
	private String word;
	
	// A list of previous words that the player has guessed.
	private LinkedList<Character> guesses;
	
	// Increments if the user guesses a wrong letter that has not already been used.
	private int boardState;
	
	// Keeps track of the current representation of the board, _ _ _ _ _ _ style. Each element is a letter node. 
	// I have omitted the space for now. Later when we convert to a string I will concatenate spaces in.
	private LinkedList<Character> boardRepresentation;
	
	/**
	 * Returns true or false as to whether or not the char exists in our word.
	 * 
	 * A-Z and a-z are all unique. 26 letters in alphabet * 2 = 52 unique letters.
	 * 
	 * @param guess
	 * @return boolean
	 */
	private boolean containsChar(char guess) {
		
		for (int i = 0; i < this.word.length(); i++) {
			
			if (this.word.charAt(i) == guess) {
				
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * 
	 * @param word
	 */
	
	public LinkedListGameModel(String word) {
		
		this.word = word;
		this.guesses = new LinkedList<>();
		this.boardState = 0;
		
		// Initialize the board representation. letter node -> space node -> letter node -> space node -> ... -> null
		this.boardRepresentation = new LinkedList<>();
		
		for (int i = 0; i < this.word.length(); i++) {
			
			this.boardRepresentation.append('_');
		}
		
		//System.out.println(this.boardRepresentation.size());
	}

	/**
	 * Returns true if the character `guess` is a prior guess. That
	 * is, the character has been used in a prior guess. Returns
	 * false otherwise. This method assumes that `guess` is an
	 * uppercase or lowercase letter in A-Za-z.
	 */
	@Override
	public boolean isPriorGuess(char guess) {
		
		if (this.guesses.contains(guess)) {
			
			return true;
		}
		
		return false;
	}

	/**
	 * Returns the number of guesses guessed so far. This should
	 * only be the number of non-repeated guesses.
	 */
	@Override
	public int numberOfGuesses() {
		
		return this.guesses.size();
	}

	/**
	 * Returns true if the character is a correct guess in the
	 * word. A correct guess is a character that is in the word
	 * but has not been guessed yet. Returns false otherwise.
	 * This method assumes that `guess` is an uppercase or lowercase 
	 * letter in A-Za-z. 
	 */
	@Override
	public boolean isCorrectGuess(char guess) {
		
		if (!this.isPriorGuess(guess) && this.containsChar(guess)) {
			
			return true;
		}
		
		return false;
	}

	/**
	 * doMove will play the character `guess` on the hangman
	 * game board if it is a character that has not already
	 * been guessed. It will replace each '_' on the game board
	 * that corresponds to a correct guess with the actual letter.
	 * 
	 * Returns true if the character was able to be placed on the
	 * game board and false if the letter was guessed previously.
	 * 
	 * To be more specific, it returns true if and only if the character 
	 * guessed revealed a hidden character in the word. Otherwise, 
	 * returns false:
	 * 
	 *	Example:
	 *  Hidden word: hello
	 *  Guess: e
	 *    returns true
	 *  Guess: e
	 *    returns false
	 *  Guess: f
	 *    returns false
	 *  Guess: l
	 *    returns true
	 *  Guess: l
	 *   returns false
	 *   
	 *  Any time the user guesses a character that is not in the 
	 *  hidden word (unless it has been previously guessed), 
	 *  the state of the board should increment.
	 *  
	 *  Example:
	 *  Hidden word: Zigzag
	 *   State: 0
	 *  Guess: g
	 *   State: 0
	 *  Guess: g
	 *   State 0
	 *  Guess: n
	 *   State: 1
	 *  Guess: n
	 *   State: 1
	 *  Guess: n
	 *   State: 1
	 *  Guess: z
	 *   State: 1
	 *  Guess: Z
	 *   State: 1
	 * 
	 * Any time the user guesses a character that was not previously guessed, 
	 * it should be appended to the list returned by previousGuessString().
	 * 
	 * Example:
	 * Hidden word: snow
	 *  Guess: u
	 *  previousGuessString(): [u]
	 *  Guess: u
	 *  previousGuessString(): [u]
	 *  Guess: n
	 *  previousGuessString(): [u, n]
	 *  Guess: n
	 *  previousGuessString(): [u, n]
	 *  Guess: s
	 *  previousGuessString(): [u, n, s]
	 *  
	 * Notice that the elements listed are in the order they were entered. 
	 * This means you will not be able to keep track of the guessed letters 
	 * using only an array of booleans; you must remember the order they 
	 * were guessed.
	 * 
	 * This method assumes that `guess` is an uppercase or lowercase 
	 * letter in A-Za-z.
	 * 
	 * I assume that A-Z and a-z are unique. So there are double the possibilities.
	 */
	@Override
	public boolean doMove(char guess) {
		
		// Has not been guessed, and is correct.
		if (!this.isPriorGuess(guess) && this.isCorrectGuess(guess)) {
			
			// Update board representation.
			this.addToBoard(guess);
			
			// Update guess list.
			this.guesses.append(guess);
			
			return true;
		}
		
		// Has not been guessed, and is incorrect.
		else if (!this.isPriorGuess(guess) && !this.isCorrectGuess(guess)) {
			
			// Update board state
			this.boardState++;
			
			// Update guess list.
			this.guesses.append(guess);
		}
		
		// Has been guessed, is correct
		// Has been guessed, is incorrect
		return false;
	}
	
	public void addToBoard(char guess) {
		
		// Iterate through the word.
		for (int i = 0; i < this.word.length(); i++) {
			
			// If the a char in the word matches the guess char
			if (this.word.charAt(i) == guess) {
				
				// Replace the '_' in the board at i, with the guess char.
				this.boardRepresentation.set(i, guess);
			}
		}
	}
	
	public boolean fullBoard() {
		
		for (int i = 0; i < this.boardRepresentation.size(); i++) {
			
			if (this.boardRepresentation.get(i) == '_') {
				
				return false;
			}
		}
		
		return true;
	}

	/**
	 * Returns true if the game board is in a winning state. That is,
	 * all the letters have been guessed correctly. Returns false
	 * otherwise.
	 */
	@Override
	public boolean inWinningState() {
		
		// There are 10 states to be in; if we fill the board before reaching state 10, then we have won.
		if (this.boardState < 10 && this.fullBoard()) {
			
			return true;
		}
		
		return false;
	}

	/**
	 * Returns true if the game board is in a losing state, that is, 
	 * the game board has reached its final state without all letters in the
	 * word having been guessed.
	 */
	@Override
	public boolean inLosingState() {
		
		// If the board is not filled, and we have reached boardState 10, then we have lost.
		if (this.boardState == 10 && !this.fullBoard()) {
			
			return true;
		}
		
		return false;
	}

	/**
	 * Returns the current "hung state". The state of the game can be
	 * one of the following:
	 * 
	 *  0   : the starting state (see HangManConstants.STARTING_STATE.)
	 *  1-9 : each of the corresponding hang man states that you can be
	 *        in after each bad guess (see ConsoleGameOutput).
	 */
	@Override
	public int getState() {
		
		return this.boardState;
	}
	

	/**
	 * Returns a string representation of the previous guesses that have
	 * been made (without repeated guesses). Here is an example of a string
	 * with 9 guesses:
	 * 
	 *  [a, e, i, o, u, m, n, t, s]
	 *  
	 * Note: this will include both correct guesses and incorrect guesses.
	 * 
	 * The returned string must be in the order the characters were played.
	 * It is important that you have spaces after each ',' for the implementation 
	 * to be correct.
	 * 
	 * If no guesses have been made, this method should return a String
	 * consisting of an empty pair of square brackets ("[]"), with no
	 * spaces or commas.
	 */	
	@Override
	public String previousGuessString() {
		
		// If the guesses list is empty
		if (this.guesses.isEmpty()) {
			
			return new String("[]");
		}
		
		String display = "";
		
		display = display.concat("[");
		
		for (int i = 0; i < this.guesses.size(); i++) {
			
			display = display.concat(this.guesses.get(i).toString());
			
			if (i != this.guesses.size() - 1) {
				
				display = display.concat(", ");
			}
		}
		
		display = display.concat("]");
		
		return display;
	}
	
	/**
	 * Returns a string representation of the board. For example, a word
	 * with 5 characters without any correct guesses will return the string:
	 * 
	 *  "_ _ _ _ _"
	 * 
	 * (With the " not being part of the string)
	 * 
	 *  A word with 6 characters with a correct guess of 'n', 'i', and 'r'
	 *  will return the string:
	 *  
	 *  "_ i n n _ r"
	 *  
	 *  Note that the strings must be in this exact format for the tests to
	 *  pass. It is important that you have spaces between each of the
	 *  letters and/or '_' for the implementation to be correct.
	 */	
	@Override
	public String toString() {
		
		String display = "";
		
		for (int i = 0; i < this.boardRepresentation.size(); i++) {
			
			display = display.concat(this.boardRepresentation.get(i).toString());
			
			if (i != this.boardRepresentation.size() - 1) {
				
				display = display.concat(" ");
			}
		}
		
		return display;
	}
	
	  /**
	 * Returns the word that the player is trying to guess.
	 */
	public String getWord() {
		
		return this.word;
	}
}
