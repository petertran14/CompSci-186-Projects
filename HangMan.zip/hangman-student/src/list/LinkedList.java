/*
 * Copyright 2017 Marc Liberatore.
 */

package list;

public class LinkedList<E> {
	
	private Node<E> head;
	private Node<E> tail;
	
	public LinkedList() {
		this.head = null;
		this.tail = null;
	}
	
	/**
	 * 
	 * @return the number of elements in this list
	 */
	public int size() {
		
		int count = 0;
		
		// Instantiate a temp variable so we don't change head.
		Node<E> copy = this.head;
		
		// Traverse the list
		while (copy != null) {
			
			copy = copy.getNext();
			
			// Increment for every element.
			count++;
		}
		
		return count;
	}
	
	/**
	 * 
	 * @param e the element search for
	 * @return true iff the list contains an element of whose value equals that of e
	 */
	public boolean contains(E e) {
	
		// Temp variable.
		Node<E> copy = this.head;
		
		// Traverse the list.
		while (copy != null) {
			
			// If we have found the element we were looking for.
			if (copy.getValue() == e) {
				
				return true;
			}
			
			copy = copy.getNext();
		}
		
		// Only reached if we have traversed the whole list and did not find e.
		return false;
	}
	
	public E getHead() {
		
		return this.head.getValue();
	}
	
	public E getTail() {
		
		return this.tail.getValue();
	}
	
	/**
	 * Replaces the element at the specified position in this list with the specified element.
	 * 
	 * @param index
	 * @param element
	 * @return the element previously at the position.
	 */
	public E set(int index, E element) {
		
		// Removing alters the size so we would like to remember the original size
		int size = this.size();
		
		//First, the element in that position must be removed.
		E value = this.remove(index);
		
		// Replace with the new node.
		Node<E> node = new Node<>(element);
		
		// We are adding to the front of the list
		if (index == 0) {
			
			node.setNext(this.head);
			this.head = node;
		}
		
		// We are adding to the end of the list
		else if (index == size) {
			
			this.append(element);
		}
		
		else {
			
			int count = 0;
			Node<E> copy = this.head;
			
			// Go to the node before the desired node.
			while (count < index - 1) {
				
				copy = copy.getNext();
				count++;
			}
			
			node.setNext(copy.getNext());
			copy.setNext(node);
		}
		
		return value;
	}
	
	/**
	 * Removes the element at the specified position in this list.
	 * 
	 * @param index
	 * @return E
	 * @throws IndexOutOfBoundsException
	 */
	public E remove(int index) throws IndexOutOfBoundsException {
		
		E value = null;
		
		// If index is greater than the size of our list or is negative.
		if (index > this.size() || index < 0) {
			
			// Indicate error.
			throw new IndexOutOfBoundsException();
		}
		
		// If we are removing the only element in the list.
		else if (this.size() == 1) {
			
			value = this.head.getValue();
			this.head = null;
			this.tail = null;
		}
		
		// If we are removing the first element in the list
		else if (index == 0) {
			
			value = this.head.getValue();
			Node<E> copy = this.head;
			this.head = this.head.getNext();
			copy.setNext(null);
		}
		
		// If we are removing the last element in the list.
		else if (index == this.size() - 1) {
			
			// Get the value that was at tail.
			value = this.tail.getValue();
			
			Node<E> copy = this.head;
			
			// Traverse until we are one node behind tail.
			while (copy.getNext().getNext() != null) {
				
				copy = copy.getNext();
			}
			
			// Update tail to point to the node behind it.
			this.tail = copy;
			
			// Set tail's next pointer to null.
			this.tail.setNext(null);
		}
		
		else {
		
			int count = 0;
			Node<E> copy = this.head;
			
			// Go to the node before the desired node.
			while (count < index - 1) {
				
				copy = copy.getNext();
				count++;
			}
			
			// We are a node behind the garbage node. So, we make a temp Node to hold the garbage node.
			Node<E> garbage = copy.getNext();
			
			// Get the value from the node to be deleted 
			value = garbage.getValue();
			
			// Set the node behind garbage to point to the node after garbage.
			copy.setNext(copy.getNext().getNext());
			
			// Isolate garbage so it can deleted.
			garbage.setNext(null);
		}
		
		// Return the value that was in garbage.
		return value;
	}
	
	/**
	 * Appends the element e to the end of the list.
	 * 
	 * @param e the value to append
	 */
	public void append(E e) {
		
		// New node that holds value of e, and next of null.
		Node<E> node = new Node<>(e);
	
		// If this is the first node in the list.
		if (this.isEmpty()) {
			
			// Both head and tail point to the same node.
			this.head = node;
			this.tail = node;
		}
		
		// This is not the first node in the list.
		else {
			
			// Tail's next node is the new node.
			this.tail.setNext(node);
			
			// Update tail.
			this.tail = this.tail.getNext();
		}
	}
	
	/**
	 * Returns the value of a Node in the Linked List at the desired index.
	 * 
	 * @param index
	 * @return E
	 * @throws IndexOutOfBoundsException
	 */
	public E get(int index) throws IndexOutOfBoundsException {
		
		// If index is greater than the size of our list or is negative.
		if (index > this.size() || index < 0) {
			
			// Indicate error.
			throw new IndexOutOfBoundsException();
		}
		
		int count = 0;
		Node<E> copy = this.head;
		
		// Traverse the list.
		while (count < index) {
			
			copy = copy.getNext();
			count++;
		}
		
		// Return the value at the specified node.
		return copy.getValue();
	}
	
	/**
	 * Returns true or false whether or not the list is empty.
	 * 
	 * @return boolean
	 */
	public boolean isEmpty() {
		
		return this.head == null;
	}
	
	public void display() {
		
		Node<E> copy = this.head;
		
		while (copy != null) {
			
			System.out.println(copy.getValue());
			copy = copy.getNext();
		}
	}
	
	
	@Override
	public String toString() {
		// TODO
		return this.head.getValue() + " " + this.tail.getValue();
	}
}
