/*
 * Copyright 2017 Marc Liberatore.
 */

package puzzle;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;
import java.util.concurrent.TimeUnit;


import search.SearchProblem;

public class EightPuzzleTest {
//	@Rule
//	public Timeout globalTimeout = new Timeout(500L, TimeUnit.MILLISECONDS);

	private SearchProblem<List<Integer>> solvedPuzzle;
	private SearchProblem<List<Integer>> oneStepPuzzle;
	private final List<Integer> solved = Arrays.asList(new Integer[] {1, 2, 3, 4, 5, 6, 7, 8, 0});
	private final List<Integer> oneStep = Arrays.asList(new Integer[] {1, 2, 3, 4, 5, 0, 7, 8, 6});
	private final int board[][] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 0}};
	
	List<Integer> invalidDuplicate = Arrays.asList(new Integer[] {0, 0, 2, 3, 4, 5, 6, 7, 8});
	List<Integer> invalidEmpty = Arrays.asList(new Integer[] {});
	List<Integer> invalidTooSmall = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 8});
	List<Integer> invalidTooBig = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 7, 8, 0});
	List<Integer> invalidNumbers = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 10, 8});
	List<Integer> invalidWeirdNumbers = Arrays.asList(new Integer[] {00, 1, 2, 3, 4, 5, 6, 10, 8});
	List<Integer> invalidFractions = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 7/7, 8});
	List<Integer> invalidLastTwo = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 7, 7});
	
	EightPuzzle eightPuzzleInitial = new EightPuzzle(Arrays.asList(new Integer[] {1, 2, 3, 4, 0, 6, 7, 5, 8 }));
	List<Integer> initial = Arrays.asList(new Integer[] {1, 2, 3, 4, 0, 6, 7, 5, 8});
	List<List<Integer>> successors = new ArrayList<>();
	
	List<Integer> s1 = Arrays.asList(new Integer[] {1, 0, 3, 4, 2, 6, 7, 5, 8});
	// s1 should have 3 successors including the original
	List<Integer> s1s = Arrays.asList(new Integer[] {1, 2, 3, 4, 0, 6, 7, 5, 8});
	List<Integer> s3s = Arrays.asList(new Integer[] {0, 1, 3, 4, 2, 6, 7, 5, 8});
	List<Integer> s2s = Arrays.asList(new Integer[] {1, 3, 0, 4, 2, 6, 7, 5, 8});
	
	
	List<Integer> s2 = Arrays.asList(new Integer[] {1, 2, 3, 4, 5, 6, 7, 0, 8});
	List<Integer> s3 = Arrays.asList(new Integer[] {1, 2, 3, 4, 6, 0, 7, 5, 8});
	List<Integer> s4 = Arrays.asList(new Integer[] {1, 2, 3, 0, 4, 6, 7, 5, 8});

	@Before
	public void before() {
		solvedPuzzle = new EightPuzzle(solved);
		oneStepPuzzle = new EightPuzzle(oneStep);
		
		successors.add(s1);
		successors.add(s2);
		successors.add(s3);
		successors.add(s4);
	}
	
	@Test
	public void testSuccessorStartingFromMiddle() {
		
		assertEquals(successors, eightPuzzleInitial.getSuccessors(initial));
		
		List<List<Integer>> successorsOf = new ArrayList<>();
		successorsOf.add(s1s);
		successorsOf.add(s2s);
		successorsOf.add(s3s);
		
		assertEquals(successorsOf, eightPuzzleInitial.getSuccessors(successors.get(0)));
	}
	
	
	@Test(expected = IllegalArgumentException.class)
	public void testEightPuzzleLastTwo() {
		
		EightPuzzle foo = new EightPuzzle(invalidLastTwo);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testEightPuzzleDuplicate() {
		
		EightPuzzle foo = new EightPuzzle(invalidDuplicate);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testEightPuzzleEmpty() {
		
		EightPuzzle foo = new EightPuzzle(invalidEmpty);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testEightPuzzleTooSmall() {
		
		EightPuzzle foo = new EightPuzzle(invalidTooSmall);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testEightPuzzleTooBig() {
		
		EightPuzzle foo = new EightPuzzle(invalidTooBig);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testEightPuzzleInvalidNumber() {
		
		EightPuzzle foo = new EightPuzzle(invalidNumbers);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testEightPuzzleInvalidWeirdNumber() {
		
		EightPuzzle foo = new EightPuzzle(invalidWeirdNumbers);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testEightPuzzleInvalidFractions() {
		
		EightPuzzle foo = new EightPuzzle(invalidFractions);
	}

	@Test
	public void testInitialState() {
		assertEquals(solved, solvedPuzzle.getInitialState());
		assertEquals(oneStep, oneStepPuzzle.getInitialState());
	}

	@Test
	public void testIsGoalState() {
		assertTrue(solvedPuzzle.isGoal(solved));
		assertTrue(oneStepPuzzle.isGoal(solved));
	}

//	@Test
//	public void testSuccessors() {
//		List<List<Integer>> successors = oneStepPuzzle.getSuccessors(oneStep);
//		assertEquals(3, successors.size());
//		assertTrue(successors.contains(solved));
//		assertTrue(successors.contains(Arrays.asList(new Integer[] {1, 2, 0, 4, 5, 3, 7, 8, 6})));
//		assertTrue(successors.contains(Arrays.asList(new Integer[] {1, 2, 3, 4, 0, 5, 7, 8, 6})));
//	}

}
