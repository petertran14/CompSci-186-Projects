/*
 * Copyright 2017 Marc Liberatore.
 */

package search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * An implementation of a Searcher that performs an iterative search,
 * storing the list of next states in a Queue. This results in a
 * breadth-first search.
 * 
 * @author liberato
 *
 * @param <T> the type for each vertex in the search graph
 */

// This class merely adds some more functionality to the interface. 
public class Searcher<T> {
	private final SearchProblem<T> searchProblem;
	
	// Helps us track our path.
	Map<T, T> predecessor;
	
	/**
	 * Instantiates a searcher.
	 * 
	 * @param searchProblem
	 *            the search problem for which this searcher will find and
	 *            validate solutions
	 */
	public Searcher(SearchProblem<T> searchProblem) {
		
		// FindIntegerProblem implements the interface SearchProblem.
		this.searchProblem = searchProblem;
	}

	/**
	 * Finds and return a solution to the problem, consisting of a list of
	 * states.
	 * 
	 * The list should start with the initial state of the underlying problem.
	 * Then, it should have one or more additional states. Each state should be
	 * a successor of its predecessor. The last state should be a goal state of
	 * the underlying problem.
	 * 
	 * If there is no solution, then this method should return an empty list.
	 * 
	 * Basically a breadth first search. What is the path from the 
	 * start integer to the goal integer.
	 * 
	 * @return a solution to the problem (or an empty list)
	 */
	public List<T> findSolution() {	
		
		// Frontier for expansion.
		Queue<T> frontier = new LinkedList<>();
		
		// Adding the initial state, for this problem is the Integer 0.
		frontier.add(searchProblem.getInitialState());
		
		// This map will help us backtrack the path to the solution.
		predecessor = new HashMap<>();
		predecessor.put(searchProblem.getInitialState(), null);
		
		// This list will store all the integers that be back-pedaled.
		List<T> path = new ArrayList<>();
		
		// While there are still frontiers to expand to.
		while(!frontier.isEmpty()) {
			
			// Get the head node.
			T current = frontier.remove();
			
			// Expand the node, find its neighbors and loop through them.
			for (T next : searchProblem.getSuccessors(current)) {
				
				// If the neighbors are new to our map.
				if (!predecessor.containsKey(next)) {
					
					// Add to map and queue.
					predecessor.put(next, current);
					frontier.add(next);
				}
			}
			
			// We have found a goal
			if (searchProblem.isGoal(current)) {
				
				// Pushfront that node to our path.
				path.add(current);
				
				// The previous node is the item that is mapped to the key.
				T previous = predecessor.get(current);
				
				// Back-pedal to the start node.
				while (previous != null) {
					
					// Push-front the nodes to the path.
					path.add(0, previous);
					
					// Backward traversing.
					previous = predecessor.get(previous);
				}
				
				// Prevents an infinite loop when nodes have infinite branches.
				break;
			}
		}
		
		return path;
	}

	/**
	 * Checks that a solution is valid.
	 * 
	 * A valid solution consists of a list of states. The list should start with
	 * the initial state of the underlying problem. Then, it should have one or
	 * more additional states. Each state should be a successor of its
	 * predecessor. The last state should be a goal state of the underlying
	 * problem.
	 * 
	 * @param solution
	 * @return true iff this solution is a valid solution
	 * @throws NullPointerException
	 *             if solution is null
	 */
	public final boolean isValidSolution(List<T> solution) {
		
		/*
		 * 1. Solution should start with initial.
		 * 2. Solution should have at least one path.
		 * 3. Solution should end with one of the goals;
		 * 4. A nullptr should not be a solution.
		 */
		
		if (solution == null) {
			
			throw new NullPointerException();
		}
		
		if (solution.isEmpty()) {
			
			return false;
		}
		
		// An invalid solution does not start with the initial state.
		if (!this.searchProblem.getInitialState().equals(solution.get(0))) {
			
			return false;
		}
		
		// An invalid solution does not end with the goal state.
		if (!searchProblem.isGoal(solution.get(solution.size() - 1))) {
			
			return false;
		}
		
		// Validate that each element is the predecessor of the next.
		for (int i = 0; i < solution.size() - 1; i++) {
			
			if (!this.searchProblem.getSuccessors(solution.get(i)).contains(solution.get(i + 1))) {
				
				return false;
			}
		}
		
		return true;
	}
}
