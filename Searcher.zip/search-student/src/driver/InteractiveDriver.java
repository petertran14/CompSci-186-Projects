package driver;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import puzzle.EightPuzzle;

public class InteractiveDriver {

	public static void main(String[] args) {
		
		List<Integer> state = Arrays.asList(new Integer[] {1, 2, 3, 4, 5, 6, 7, 8, 0});
		List<Integer> allFour = Arrays.asList(new Integer[] {1, 2, 3, 4, 0, 5, 7, 8, 6});
		List<Integer> allThree = Arrays.asList(new Integer[] {1, 2, 3, 4, 5, 0, 6, 7, 8});
		List<Integer> allTwo = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 7, 8});
		
		List<Integer> invalidDuplicate = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 5, 7, 8});
		List<Integer> invalidEmpty = Arrays.asList(new Integer[] {});
		List<Integer> invalidTooSmall = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 8});
		List<Integer> invalidTooBig = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 7, 8});
		List<Integer> invalidNumbers = Arrays.asList(new Integer[] {0, 1, 2, 3, 4, 5, 6, 10, 8});
		
		//System.out.println(invalidTooBig.size());
		
//		for (int i = 0; i < invalidTooBig.size(); i++) {
//			
//			System.out.println(invalidTooBig.get(i));
//		}
//		
//		System.out.println("Done");
		
		EightPuzzle foo = new EightPuzzle(invalidNumbers);
		//foo.getSuccessors(allThree);
		//foo.display();
		
//		Integer[] original = new Integer[] {1,2};
//		
//		System.out.println(original[0] + ", " + original[1]);
//		
//		Integer[] copy = original;
//		
//		System.out.println(copy[0] + ", " + copy[1]);
//		copy[0] = 5;
//		
//		System.out.println(original[0] + ", " + original[1]);
//		System.out.println(copy[0] + ", " + copy[1]);
	}
}
