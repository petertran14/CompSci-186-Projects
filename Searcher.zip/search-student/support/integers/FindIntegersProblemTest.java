package integers;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

public class FindIntegersProblemTest {

	@Rule
	public Timeout globalTimeout = Timeout.seconds(10); // 10 seconds
	
	FindIntegersProblem foo;
	
	@Before
	public void before() {
		
		foo = new FindIntegersProblem(2, -1, true);
	}

	@Test
	public void testInitialState() {
		
		Integer empty = 0;
		assertEquals(empty, foo.getInitialState());
	}
	
	@Test
	public void testNoGoalYet() {
		
		Integer empty = 0;
		assertFalse(foo.isGoal(empty));
	}
	
	@Test
	public void testExpandOnce() {
		
		List<Integer> list = new ArrayList<>();
		
		list.add(1);
		list.add(-1);
		Integer currentState = 0;
		
		assertEquals(list, foo.getSuccessors(currentState));
		assertFalse(foo.isGoal(list.get(0)));
		assertTrue(foo.isGoal(list.get(1)));
	}
	
	@Test 
	public void testExpandTwice() {
		
		List<Integer> list = new ArrayList<>();
		Integer currentState = 0;
		
		foo.getSuccessors(currentState);
		list.add(1);
		list.add(-1);
		
		Integer positiveState = 1;
		foo.getSuccessors(positiveState);
		list.add(2);
		
		Integer negativeState = -1;
		foo.getSuccessors(negativeState);
		list.add(-2);
		
		assertEquals(Arrays.asList(new Integer[] {positiveState + 1, positiveState - 1}), foo.getSuccessors(positiveState));
		assertEquals(Arrays.asList(new Integer[] {negativeState + 1, negativeState - 1}), foo.getSuccessors(negativeState));
		
		assertFalse(foo.isGoal(list.get(0)));
		assertTrue(foo.isGoal(list.get(1)));
		assertTrue(foo.isGoal(list.get(2)));
		assertFalse(foo.isGoal(list.get(3)));
	}
}
