package index;

import java.util.HashSet;
import java.util.Set;

public class Driver {
	
	public static void main(String[] args) {
		
		int a = 5;
		double b = 2.567;
		
		System.out.println((double)a * b);
	}
}
