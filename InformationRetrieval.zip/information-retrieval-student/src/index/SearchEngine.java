/*
 * Copyright 2017 Marc Liberatore.
 */

package index;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.io.Reader;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import comparators.TfIdfComparator;
import documents.DocumentId;

/**
 * A simplified document indexer and search engine.
 * 
 * Documents are added to the engine one-by-one, and uniquely identified by a DocumentId.
 *
 * Documents are internally represented as "terms", which are lowercased versions of each word 
 * in the document. 
 * 
 * Queries for terms are also made on the lowercased version of the term. Terms are 
 * therefore case-insensitive.
 * 
 * Lookups for documents can be done by term, and the most relevant document(s) to a specific term 
 * (as computed by tf-idf) can also be retrieved.
 *
 * See:
 * - <https://en.wikipedia.org/wiki/Inverted_index>
 * - <https://en.wikipedia.org/wiki/Search_engine_(computing)> 
 * - <https://en.wikipedia.org/wiki/Tf%E2%80%93idf>
 * 
 * @author Marc Liberatore
 *
 */
public class SearchEngine {
	
	Map<String, Set<DocumentId>> engine;
	Map<DocumentId, Map<String, Integer>> termCount;
	//Map<String, Integer> innerMap;
	
	public SearchEngine() {
		
		this.engine = new HashMap<>();
		this.termCount = new HashMap<>();
		//this.innerMap = new HashMap<>();
	}
	
	/**
	 * Inserts a document into the search engine for later analysis and retrieval.
	 * 
	 * The document is uniquely identified by a documentId; attempts to re-insert the same 
	 * document are ignored.
	 * 
	 * The document is supplied as a Reader; this method stores the document contents for 
	 * later analysis and retrieval.
	 * 
	 * @param documentId
	 * @param reader
	 * @throws IOException iff the reader throws an exception 
	 */
	public void addDocument(DocumentId documentId, Reader reader) throws IOException {
		
		// Goal: read from the document, store both ID and the "Terms" of the document in the map
		try {
			
			Map<String, Integer> innerMap = new HashMap<>();
			
			// Update our termCount map so that later it can calculate termFrequency
			if (!this.termCount.containsKey(documentId)) {
				
				this.termCount.put(documentId, innerMap);
			}
			
			BufferedReader file = new BufferedReader(reader);
			Set<DocumentId> id = new HashSet<>();
			String[] word;
			int count = 0;
		
			// Read line by line, splitting based on non-word characters. 
			// Also converting each line to lowercase.
			// I may need to handle empty strings.
			for (String line = file.readLine(); line != null; line = file.readLine()) {
				
				// Splits the line around non-word characters.
				//word.add(line.split("\\W+"));
				word = line.split("\\W+");
				
				for (int i = 0; i < word.length; i++) {
					
					// Convert the word to lower-case.
					word[i] = word[i].toLowerCase();
					
					// If the engine map does not have the word
					if (!this.engine.containsKey(word[i])) {
						
						// Add a new word(key) and associate with it an empty set.
						this.engine.put(word[i], new HashSet<>());
					}
					
					// The set of ID's points to the set inside the map.
					id = this.engine.get(word[i]);
					
					// Add to the set.
					id.add(documentId);
					
					// Returns the integer that represents how many times this word showed up in the line.
					// If the innerMap doesn't know about the word, this returns 0.
					count = innerMap.getOrDefault(word[i], 0);
					
					// Put the word in the innerMap and increment count.
					innerMap.put(word[i], count + 1);
					
					// Or this works the same...
					
//					// If the termCount inner map does not have the word
//					if (!this.termCount.get(documentId).containsKey(word[i])) {
//						
//						// The particular word is associated to an integer frequency at which it appears.
//						innerMap.put(word[i], count++);
//					}
//				
//					else {
//						
//						count = innerMap.get(word[i]);
//						innerMap.put(word[i], count++);
//					}
				}
			}
			
		} catch (IOException ex) {
			
			throw new IOException();
		}
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((engine == null) ? 0 : engine.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SearchEngine other = (SearchEngine) obj;
		if (engine == null) {
			if (other.engine != null)
				return false;
		} else if (!engine.equals(other.engine))
			return false;
		return true;
	}

	/**
	 * Returns the set of DocumentIds contained within the search engine that contain a given term.
	 * 
	 * @param term
	 * @return the set of DocumentIds that contain a given term
	 */
	public Set<DocumentId> indexLookup(String term) {
		
		// Make a copy
		Set<DocumentId> copy = new HashSet<>();
		
		// Loop through the set of strings
		for (String key : this.engine.keySet()) {
			
			// If the term converted to lower case matches a key, then they are semantically equal
			if (term.toLowerCase().equals(key)) {
				
				// Get the set associated with the key.
				copy = this.engine.get(term.toLowerCase());
			}
		}
		
		return copy;
	}
	
	/**
	 * Returns the term frequency of a term in a particular document.
	 * 
	 * The term frequency is number of times the term appears in a document.
	 * 
	 * See 
	 * @param documentId
	 * @param term
	 * @return the term frequency of a term in a particular document
	 * @throws IllegalArgumentException if the documentId has not been added to the engine
	 */
	public int termFrequency(DocumentId documentId, String term) throws IllegalArgumentException {
		
		// If the doucment ID is not within our termCount map.
		if (!this.termCount.containsKey(documentId)) {
			
			throw new IllegalArgumentException();
		}
		
		// If the term exists for the specified document, return the number of times it appeared.
		// Else return 0.
		int count = this.termCount.get(documentId).getOrDefault(term, 0);
		
		return count;
	}
	
	/**
	 * Returns the inverse document frequency of a term across all documents in the index.
	 * 
	 * For our purposes, IDF is defined as log ((1 + N) / (1 + M)) where 
	 * N is the number of documents in total, and M
	 * is the number of documents where the term appears.
	 * 
	 * @param term
	 * @return the inverse document frequency of term 
	 */
	public double inverseDocumentFrequency(String term) {
		
		// Represents N and M
		double numDoc = this.termCount.size();
		double termAppear = 0.0;
		
		// If the the engine map contains the key
		if (this.engine.containsKey(term)) {
		
			// Get the number of documents this term appears in.
			termAppear = this.engine.get(term).size();
		}
		
		return Math.log((1 + numDoc) / (1 + termAppear));
	}
	
	/**
	 * Returns the tfidf score of a particular term for a particular document.
	 * 
	 * tfidf is the product of term frequency and inverse document frequency for the given term and document.
	 * 
	 * @param documentId
	 * @param term
	 * @return the tfidf of the the term/document
	 * @throws IllegalArgumentException if the documentId has not been added to the engine
	 */
	public double tfIdf(DocumentId documentId, String term) throws IllegalArgumentException {
		
		return (this.termFrequency(documentId, term) * this.inverseDocumentFrequency(term));
	}
	
	/**
	 * Returns a sorted list of documents, most relevant to least relevant, for the given term.
	 * 
	 * A document with a larger tfidf score is more relevant than a document with a lower tfidf score.
	 * 
	 * Each document in the returned list must contain the term.
	 * 
	 * @param term
	 * @return a list of documents sorted in descending order by tfidf
	 */
	public List<DocumentId> relevanceLookup(String term) {
		
		// Empty set
		Set<DocumentId> set = new HashSet<>();
		
		// List to hold the document Id.
		List<DocumentId> list = new ArrayList<>();
		
		// If the term does not exist
		if (this.indexLookup(term).equals(set)) {
			
			// Return an empty list
			return list;
		}
		
		// The set of document Ids associated with the term.
		set = this.engine.get(term);
		
		// Loop through the set/
		for (DocumentId id : set) {
			
			// Add the elements to the list
			list.add(id);
		}
		
		// Sort the list: bigger tf-idf score goes first.
		list.sort(new TfIdfComparator(this, term));
		
		// Return the list
		return list;
	}
}
