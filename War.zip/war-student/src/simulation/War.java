/*
 * Copyright 2017 Marc Liberatore.
 */

package simulation;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * 
 * A Java class to simulate the card game War. See assignment writeup for details.
 * 
 * @author liberato
 *
 */
public class War {
	
	private final int THOUSAND = 1000;
	
	// Adding cards to the tail of the deck, and pulling from the head of the deck.
	// A Queue seems like a good candidate for these functions.
	private Queue<Integer> playerA;
	private Queue<Integer> playerB;
	private Queue<Integer> spoils;
	private int battleCount;
	
	private List<Integer> deck;
	
	private int winner;
	private boolean endGame;

	public War(List<Integer> deck) {
		
		this.deck = deck;
		this.playerA = new LinkedList<>();
		this.playerB = new LinkedList<>();
		this.spoils = new LinkedList<>();
		this.battleCount = 0;
		this.winner = 0;
		this.endGame = false;
		
		this.dealCards();
	}
	
	/**
	 * Deal Cards entails getting the front of the deck, and giving it to A first, then giving the next card to B.
	 * 
	 * For example, if the initial deck contains the values [2, 3, 4, 5] and we deal out all the cards, 
	 * player A’s deck would then contain [2, 4] 
	 * and player B’s deck would contain [3, 5].
	 * 
	 * Removing gives an Unsupported Operation Exception because we have used an unmodifiable list in our tests.
	 */
	private void dealCards() {
		
		int count = 0;
		
		// While we can still get elements from the deck.
		while (count < this.deck.size()) {
			
			// A will be given the first card, and henceforth, every card after B is given a card.
			if (count % 2 == 0) {
				
				// Note: We are getting the elements are specific indexes, but are not removing them from the deck.
				this.playerA.add(this.deck.get(count));
			}
			
			else {
				
				this.playerB.add(this.deck.get(count));
			}
			
			count++;
		}
	}
	
	/**
	 * Returns an integer representation of the winner.
	 * 
	 * @return int
	 */
	public int getWinner() {
		
		return this.winner;
	}
	
	/**
	 * Returns a copy of the cards in player A's deck.
	 * 
	 * @return queue
	 */
	public Queue<Integer> getPlayerA() {
		
		return new LinkedList<>(this.playerA);
	}
	
	/**
	 * Returns a copy of the cards in player B's deck.
	 * 
	 * @return queue
	 */
	public Queue<Integer> getPlayerB() {
		
		return new LinkedList<>(this.playerB);
	}
	
	/**
	 * A battle means both players play their top cards to the spoils board. 
	 * Then we must compare, the person who played the bigger card gets the spoils.
	 * If it is a tie then we must call wage war.
	 *
	 * This method may change the endGame condition.
	 */
	public void battle() {
		
		// Check endGame conditions
		if (this.playerA.isEmpty() && this.playerB.isEmpty()) {
			
			// Indicates a draw
			this.winner = 0;
			this.endGame = true;
		}
		
		else if (!this.playerA.isEmpty() && this.playerB.isEmpty()) {
			
			this.winner = 1;
			this.endGame = true;
		}
		
		else if (this.playerA.isEmpty() && !this.playerB.isEmpty()) {
			
			this.winner = -1;
			this.endGame = true;
		}
		
		else {
			
			// Increment battle count
			this.battleCount++;
			
			// Remove from the head of the queue(top of the each player's deck) a card.
			int cardA = this.playerA.remove();
			int cardB = this.playerB.remove();
			
			// Add both cards to the spoils in the order they were removed.
			this.spoils.add(cardA);
			this.spoils.add(cardB);
			
			// If playerA laid down the bigger card, they get the spoils.
			if (cardA > cardB) {
				
				this.playerA.addAll(this.spoils);
				this.spoils.clear();
			}
			
			// If playerB laid down the bigger card, they get the spoils.
			else if (cardB > cardA) {
				
				this.playerB.addAll(this.spoils);
				this.spoils.clear();
			}
			
			// Both cards are equal in value.
			else {
				
				// If on the 1000th try, there is still no winner after battle, then exit the function, and do not call wageWar.
				if (this.battleCount == THOUSAND) {
					
					this.winner = 0;
					this.endGame = true;
					return;
				}
				
				this.wageWar();
			}
		}
	}
	
	/**
	 * Both player lay down 3 more cards to spoils collection.
	 * 
	 * If player A is unable to lay down 3 cards, and player B can, then B wins.
	 * If player B is unable to lay down 3 cards, and player A can, then A wins.
	 * If both players are unable to lay down 3 cards, draw. 
	 */
	public void wageWar() {
		
		// If both players are unable to lay down 3 cards, draw. 
		if (this.playerA.size() < 3 && this.playerB.size() < 3) {
			
			this.winner = 0;
			this.endGame = true;
		}
		
		// If player A is unable to lay down 3 cards, and player B can, then B wins.
		else if (this.playerA.size() < 3 && this.playerB.size() >= 3) {
			
			this.winner = -1;
			this.endGame = true;
		}
		
		// If player B is unable to lay down 3 cards, and player A can, then A wins.
		else if (this.playerA.size() >= 3 && this.playerB.size() < 3) {
			
			this.winner = 1;
			this.endGame = true;
		}
		
		// Add the top 3 cards of each player to the spoils collection.
		else {
			
			this.spoils.add(this.playerA.remove());
			this.spoils.add(this.playerA.remove());
			this.spoils.add(this.playerA.remove());
			
			this.spoils.add(this.playerB.remove());
			this.spoils.add(this.playerB.remove());
			this.spoils.add(this.playerB.remove());
		}
	}
	
	/**
	 * Returns and integer representation of the winner.
	 * 
	 * Calls the battle method and controls for a technical draw/endGame conditions.
	 * 
	 * @return int
	 */
	public int simulateGame() {
		
		while (this.battleCount < 1000 && !endGame) {
			
			this.battle();
		}
		
		return this.getWinner();
	}
	
	/**
	 * Determines the winner of a game of War, returning 1 if player A wins, -1 if player B wins, 0 if a draw.
	 * 
	 * The rules of the game are defined in the assignment writeup.
	 * Treat this method like a main method that can call methods from the War class
	 * 
	 * @param deck
	 * @return 1 if player A wins, -1 if player B wins, 0 if a draw
	 */
	public static int findWinner(List<Integer> deck) {
		
		War war = new War(deck);
		
		return war.simulateGame();
	}
}
