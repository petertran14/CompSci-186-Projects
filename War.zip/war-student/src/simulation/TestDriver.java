package simulation;

public class TestDriver {

	public static void main(String[] args) {
		
		System.out.println(0 % 2);
		System.out.println(1 % 2);
		System.out.println(2 % 2);
		System.out.println(3 % 2);
		System.out.println(4 % 2);
		System.out.println(5 % 2);
	}
}
