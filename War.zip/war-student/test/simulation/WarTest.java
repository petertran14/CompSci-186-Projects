/*
 * Copyright 2017 Marc Liberatore.
 */

package simulation;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;


public class WarTest {
	
	// Tests findWinner
	@Test
	public void testEmpty() {
		assertEquals(0, War.findWinner(new ArrayList<Integer>()));
	}

	@Test
	public void testOne() {
		List<Integer> deck = Arrays.asList(2);
		assertEquals(1, War.findWinner(deck));
	}

	@Test
	public void testTwoA() {
		List<Integer> deck = Arrays.asList(3, 2);
		assertEquals(1, War.findWinner(deck));
	}

	@Test
	public void testTwoB() {
		List<Integer> deck = Arrays.asList(2, 3);
		assertEquals(-1, War.findWinner(deck));
	}
	
	@Test
	public void testDraw() {
		
		List<Integer> deck = Arrays.asList(2, 2);
		assertEquals(0, War.findWinner(deck));
	}
	
	//For example, suppose that player A’s deck contained [2, 8, 9, 10, 5, 4] and player B’s deck contained [2, 6, 7, 11, 6, 4].
	
	@Test
	public void testComplicatedB() {
		
		List<Integer> deck = Arrays.asList(2, 2, 8, 6, 9, 7, 10, 11, 5, 6, 4, 4);
		assertEquals(-1, War.findWinner(deck));
	}
	
	@Test
	public void testComplicatedA() {
		
		List<Integer> deck = Arrays.asList(2, 2, 8, 6, 9, 7, 10, 11, 6, 5, 4, 4);
		assertEquals(1, War.findWinner(deck));
	}
	
//	@Test
//	public void testTechnicalDraw1000() {
//		
//		// Deck contains no duplicates of any integer.
//		List<Integer> deck = new ArrayList<>();
//		
//		// Will give each player 1500 cards. This deck will generate at least 1500 battles, well over the limit.
//		for (int i = 0; i < 1000; i++) {
//			
//			if (i % 2 == 0) {
//				
//				deck.add(1);
//			}
//			
//			else {
//				
//				deck.add(2);
//			}
//		}
//		
//		deck.add(1);
//		
//		assertEquals(0, War.findWinner(deck));
//	}
	
	// Change the Draw condition instead of 1000, to 3. If this test passes, then 1000 is likely to pass.
//	@Test
//	public void testTechnicalDraw3() {
//		
//		List<Integer> deck = new ArrayList<>();
//		deck.add(1);
//		deck.add(2);
//		deck.add(1);
//		deck.add(2);
//		deck.add(1);
//		deck.add(2);
//		deck.add(1);
//		
//		assertEquals(0, War.findWinner(deck));
//	}
	
	@Test
	public void testThreeWars() {
		
		List<Integer> deck = Arrays.asList(1, 1, 3, 3, 4, 4, 5, 5, 2, 2, 6, 6, 7, 7, 8, 8, 3, 3, 9, 9, 10, 10, 11, 11, 13, 12);
		assertEquals(1, War.findWinner(deck));
	}
	
	@Test
	public void testPlayerAWinsInWar() {
		
		List<Integer> deck = Arrays.asList(1, 1, 3, 3, 4, 4, 5, 5, 6, 2, 7, 7);
		assertEquals(1, War.findWinner(deck));
	}
	
	@Test
	public void testPlayerBWinsInWar() {
		
		List<Integer> deck = Arrays.asList(1, 1, 3, 3, 4, 4, 5, 5, 2, 6, 7, 7);
		assertEquals(-1, War.findWinner(deck));
	}
	
	// Tests for dealCard method
	@Test
	public void testEmptyDeck() {
		
		List<Integer> deck = new ArrayList<>();
		War w = new War(deck);
		
		Queue<Integer> expected = new LinkedList<>();
		
		assertEquals(expected, w.getPlayerA());
		assertEquals(expected, w.getPlayerB());
	}
	
	@Test
	public void testDealCardA() {
		
		List<Integer> deck = Arrays.asList(2, 3, 3, 4, 5, 6);
		War w = new War(deck);
		
		Queue<Integer> expected = new LinkedList<>();
		expected.add(2);
		expected.add(3);
		expected.add(5);
		
		assertEquals(expected, w.getPlayerA());
	}
	
	@Test
	public void testDealCardB() {
		
		List<Integer> deck = Arrays.asList(2, 3, 3, 4, 5, 6);
		War w = new War(deck);
		
		Queue<Integer> expected = new LinkedList<>();
		expected.add(3);
		expected.add(4);
		expected.add(6);
		
		assertEquals(expected, w.getPlayerB());
	}
	
	@Test 
	public void testExampleDealCardA() {
		
		List<Integer> deck = Arrays.asList(2, 2, 8, 6, 9, 7, 10, 11, 5, 6, 4, 4);
		War w = new War(deck);
		
		Queue<Integer> expected = new LinkedList<>();
		expected.add(2);
		expected.add(8);
		expected.add(9);
		expected.add(10);
		expected.add(5);
		expected.add(4);
		
		assertEquals(expected, w.getPlayerA());
	}
	
	@Test 
	public void testExampleDealCardB() {
		
		List<Integer> deck = Arrays.asList(2, 2, 8, 6, 9, 7, 10, 11, 5, 6, 4, 4);
		War w = new War(deck);
		
		Queue<Integer> expected = new LinkedList<>();
		expected.add(2);
		expected.add(6);
		expected.add(7);
		expected.add(11);
		expected.add(6);
		expected.add(4);
		
		assertEquals(expected, w.getPlayerB());
	}
}
