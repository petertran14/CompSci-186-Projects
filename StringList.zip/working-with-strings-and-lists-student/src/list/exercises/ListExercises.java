/*
 * Copyright 2017 Marc Liberatore.
 */

package list.exercises;

import java.util.ArrayList;
import java.util.List;

public class ListExercises {

	/**
	 * Counts the number of characters in total across all strings in the supplied list;
	 * in other words, the sum of the lengths of the all the strings.
	 * @param l a non-null list of strings
	 * @return the number of characters
	 */
	public static int countCharacters(List<String> l) {
		
		//accumulator
		int sum = 0;
		
		//get the number of Strings in this list
		for (int i = 0; i < l.size(); i++) {
			
			//get the number of char per String
			for(int ch = 0; ch < l.get(i).length(); ch++) {
				
				//increase once for every character we run through
				sum += 1;
			}
		}
		
		return sum;
	}
	
	/**
	 * Splits a string into words and returns a list of the words. 
	 * If the string is empty, split returns a list containing an empty string.
	 * 
	 * @param s a non-null string of zero or more words
	 * @return a list of words
	 */
	public static List<String> split(String s) {
		
		//given a string, I assume a sentence where the words are separated by a space.
		String[] words = s.split("\\s+");
		
		//need to create a List<String> that holds a list of the words
		List<String> list = new ArrayList<String>();
		
		//loops through each element in our array of words, and assigns it to the list
		for (int i = 0; i < words.length; i++) {
			
			list.add(words[i]);
		}
		
		//we are returning of List<String> type, although I imagine if we changed the return
		//type to String[] we can get the same result.
		return list;
	}

	/**
	 * Returns a copy of the list of strings where each string has been 
	 * uppercased (as by String.toUpperCase).
	 * 
	 * The original list is unchanged.
	 * 
	 * @param l a non-null list of strings
	 * @return a list of uppercased strings
	 */
	public static List<String> uppercased(List<String> l) {
		
		//We don't want to change l, so we need to copy over its data to a new list
		List<String> list = new ArrayList<String>(l);
		String[] s = new String[list.size()];
		
		//loop through each element of the list of strings
		for (int i = 0; i < list.size(); i++) {
			
			//store the string element as an uppercase in a string array
			s[i] = list.get(i).toUpperCase();
			
			//replace the copy of the list, with the capitalized versions
			list.set(i, s[i]);
		}
		
		return list;
	}

	/**
	 * Returns true if and only if each string in the supplied list of strings
	 * starts with an uppercase letter. If the list is empty, returns false.
	 * 
	 * @param l a non-null list of strings
	 * @return true iff each string starts with an uppercase letter
	 */
	public static boolean allCapitalizedWords(List<String> l) {
		
		boolean allCaps = true;
		
		//empty list
		if (l.size() == 0) {
			
			return false;
		}
		
		//loop through each element of strings, in the list
		for (int i = 0; i < l.size(); i++) {
			
			//if empty string
			if (l.get(i) == "") {
				
				allCaps = false;
			}
			
			if (allCaps) {
				
				//retrieve the string from the list
				String s = l.get(i);
				
				//retrieve the first char from the string
				char ch = s.charAt(0);
			
			
				//check for first letter that is capitalized
				if (!(Character.isUpperCase(ch))) {
					
					//at least one of the strings does not start with capitals
					allCaps = false;
				}
			}
		}
		
		return allCaps;
	}

	/**
	 * Returns a list of strings selected from a supplied list, which contain the character c.
	 * 
	 * The returned list is in the same order as the original list, but it omits all strings 
	 * that do not contain c.
	 * 
	 * The original list is unmodified.
	 * 
	 * @param l a non-null list of strings
	 * @param c the character to filter on
	 * @return a list of strings containing the character c, selected from l
	 */
	public static List<String> filterContaining(List<String> l, char c) {
		
		/*
		 * 1. Need to instantiate a new List<String>
		 * 2. Need to get each individual String
		 * 3. Check for char c
		 * 4. Add them to the List (add works like pushBack)
		 */
		
		//a new string list, and a string array
		List<String> copyList = new ArrayList<String>();
		String[] s = new String[l.size()];
		
		//loop through each string element of the list
		for (int i = 0; i < l.size(); i++) {
			
			//filter through a string one by one
			s[i] = l.get(i);
			
			//loop through the characters of each string
			for (int ch = 0; ch < s[i].length(); ch++) {
				
				//if the string has the letter we want, add it to the list
				if (s[i].charAt(ch) == c) {
					
					copyList.add(s[i]);
				}
			}
		}
		
		return copyList;
	}
	
	/**
	 * Inserts a string into a sorted list of strings, maintaining the sorted property of the list.
	 * 
	 * @param s the string to insert
	 * @param l a non-null, sorted list of strings
	 */
	
	//Assume a pre-sorted list of strings
	//Need to work with original list, not make a copy
	public static void insertInOrder(String s, List<String> l) {
		
		boolean once = true;
		int count = 0;
		
		//if the list is initailly empty
		if (l.size() == 0) {
			
			l.add(s);
			once = false;
		}
		
		//while we look for a place to add
		while (once) {
			
			//insert
			if (s.compareTo(l.get(count)) < 0) {
				
				l.add(count, s);
				once = false;
			}
			
			//s is the largerst, so we insert at the end
			if (count == l.size() - 1 && once) {
				
				l.add(s);
				once = false;
			}
			
			count++;
		}
	}
}
