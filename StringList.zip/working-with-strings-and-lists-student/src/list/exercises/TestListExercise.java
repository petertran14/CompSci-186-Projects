package list.exercises;

import java.util.ArrayList;
import java.util.List;

public class TestListExercise {

	public static void main(String[] args) {
		
		ExtendedArrayList<Integer> numList = new ExtendedArrayList<Integer>();
		
		numList.add(1);
		numList.add(2);
		numList.add(3);
		numList.add(4);
		numList.add(5);
		numList.add(6);
		
		//System.out.println(numList.count(5));
		
//		numList.rotateRight(2);
		
		for (int item : numList) {
			
			System.out.println(item);
		}
		
		List<Integer> list = new ArrayList<Integer>();
		
		list = numList.reversed();
		
		System.out.println();
		
		for (int form : list) {
			
			System.out.println(form);
		}
		
		
//		ExtendedArrayList<String> wordList = new ExtendedArrayList<String>();
//		wordList.add("hey");
//		wordList.add("ho");
//		wordList.add("hi");
//		
//		wordList.intersperse("yo");
//		
//		for (String item : wordList) {
//			
//			System.out.println(item);
//		}
		
//		List<String> l = new ArrayList<String>();
//		
//		System.out.println(l.size());
//		
//		if (ListExercises.allCapitalizedWords(l)) {
//			
//			System.out.println("True");
//		}
//		
//		else {
//			
//			System.out.println("False");
//		}
		
		//instantiate a new, empty list
//		List<String> list = new ArrayList<String>();
//		String s = "cruzycat";
//		String words = "I am having fun.";
//		String[] string = new String[5];
		
//		//5 elements, total of 40 chars
//		for (int i = 0; i < 5; i++) {
//			
//			list.add(s);
//		}
//		
//		System.out.println("Size: " + list.size());
//		System.out.println("Element 0: " + list.get(0));
//		System.out.println("Element 0 length: " + list.get(0).length());
//		
//		System.out.println();
//		System.out.println("Testing countCharacters Method: ");
//		
//		int sum = ListExercises.countCharacters(list);
//		
//		System.out.println("The sum is: " + sum);
//		
//		for (int i = 0; i < 5; i++) {
//			
//			string[i] = s;
//		}
//		
//		for (String item : string) {
//			
//			System.out.println(item);
//		}
//		
//		int length = string.length;
//		
//		System.out.println(length);
//		
//		System.out.println();
//		
//		//method returns a list of words which I will store in the newly instantiated variable
//		List<String> listOfWords = new ArrayList<String>(ListExercises.split(words));
//		
//		for (int i = 0; i < listOfWords.size(); i++) {
//			
//			System.out.println(listOfWords.get(i));
//		}
//		
//		//creates a list of 5 cruzycats
//		for (int i = 0; i < 5; i++) {
//			
//			list.add(i, s);
//		}
		
		//creates a list of 5 cruzycats
//		for (int i = 0; i < 5; i++) {
//			
//			list.add(i, s);
//		}
//		
//		System.out.println(list.size());
//		
//		List<String> anotherList = new ArrayList<String>(ListExercises.uppercased(list));
//	
//		System.out.println("In Main: ");
//		
//		for (String item : anotherList) {
//			
//			System.out.println(item);
//		}
//		
//		List<String> capList = new ArrayList<String>();
//		
//		capList.add("Foo");
//		capList.add("Foogly");
//		capList.add("Foo");
//		capList.add("Fooglier");
//		capList.add("Foo");
//		
//		if (ListExercises.allCapitalizedWords(capList)) {
//			
//			System.out.println("All Caps!");
//		}
//		
//		else {
//			
//			System.out.println("At Least One Not Caps");
//		}
//		
//		List<String> filterList = new ArrayList<String>(ListExercises.filterContaining(capList, 'l'));
//		
//		for (String item : filterList) {
//			
//			System.out.println(item);
//		}
		
//		List<String> sortList = new ArrayList<String>();
//		String c = "fff";
//		
//		sortList.add("aaa");
//		sortList.add("bbb");
//		sortList.add("ccc");
//		sortList.add("eee");
//		
//		ListExercises.insertInOrder(c, sortList);
//		
//		for (String item : sortList) {
//			
//			System.out.println(item);
//		}
//
//		
//		List<String> test = new ArrayList<String>();
//		
//		test.add("");
//		
//		System.out.println(test.size());
//		
//		System.out.println(test.get(0) + "hello");
		
//		if (ListExercises.allCapitalizedWords(test)) {
//			
//			System.out.println("All Caps");
//		}
//		
//		else {
//			
//			System.out.println("False");
//		}
	}
}
