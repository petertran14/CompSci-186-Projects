/*
 * Copyright 2017 Marc Liberatore.
 */

package list.exercises;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class ExtendedArrayList<E> extends ArrayList<E> {
	
	/**
	 * Counts the number of elements in this list that are equal to e.
	 * 
	 * Uses .equals to check for equality. 
	 * 
	 * @param e the element to count
	 * @return the number of elements equal to e
	 */
	public int count(E e) {
		
		//set the counter variable
		int count = 0;
		
		//loop through the object
		for (int i = 0; i < this.size(); i++) {
			
			//check if the elements in the list are equal to e
			if (this.get(i).equals(e)) {
				
				//increment
				count++;
			}
		}
		
		//return accumulator
		return count;
	}
	
	/**
	 * Rotates the list right n places.
	 * 
	 * Rotating a list right means moving the last item to the front of the list:
	 * 
	 * 1, 2, 3, 4, 5 when rotated right once becomes 5, 1, 2, 3, 4
	 * 
	 * A list is rotated right two places as follows:
	 * 
	 * 4, 5, 1, 2, 3
	 * 
	 * and so on.
	 * 
	 * @param n the distance to rotate the list right
	 */
	public void rotateRight(int n) {
		
		if (this.size() != 0) {
		
			//loop for quantity of rotations
			for (int rotate = 0; rotate < n; rotate++) {
				
				//remove the last element from the list
				E element = this.remove(this.size() - 1);
				
				//insert the last element to the front
				this.add(0, element);
			}
		}
	}	
	
	/**
	 * Intersperses e between each existing element of the list.
	 * 
	 * For example, given the list: "hey", "ho", "hi", if we intersperse "yo" we get:
	 * "hey", "yo", "ho", "yo", "hi"
	 * 
	 * @param e the element to intersperse
	 */
	public void intersperse(E e) {
		
		//loop through the list
		for (int i = 0; i < this.size(); i++) {
			
			//at every odd index, add the element
			if (i % 2 != 0) {
				
				//add the element e
				this.add(i, e);
			}
		}
	}
	
	/**
	 * Returns a copy of this list in reverse order.
	 * 
	 * This list is unmodified by this operation.
	 * 
	 * @return a reversed copy of the list
	 */
	public List<E> reversed() {
		
		List<E> copy = new ArrayList<E>(this);
		E left, right;
		int inner = 0;
		int outer = copy.size() - 1;
		int count = 0;
		
		//the amount of times to loop
		while (count < copy.size() / 2) {
			
			//do stuff
			right = copy.remove(outer);
			left = copy.remove(inner);
			
			//add the right-handed value to the left-handed space
			copy.add(inner, right);
			
			//add the left-handed value to the right-handed space
			copy.add(outer, left);
			
			//increment the left-handed index 
			//decrement the right-handed index
			//increment count
			inner++;
			outer--;
			count++;
		}
		
		return copy;
	}
}
