package string.exercises;

public class TestStringMethods {

	public static void main(String[] args) {
		
		String s = "  MARC  ";
		String note = "I ate pizza";
		String substring = "MARC";
		
		//findMarc is a static method, so the way of accessing it would
		//just to use the class name
		System.out.println("Found at index: " + StringExercises.findMarc("  Marc  "));
		
//		System.out.println("Found at index: " + StringExercises.findSubstring(s, substring));
//		
//		if (StringExercises.contains(s, substring)) {
//			
//			System.out.println("The substring MARC exists!");
//		}
//		
//		else {
//			
//			System.out.println("MARC does not exist.");
//		}
		
//		String[] part = StringExercises.splitIntoWords(note);
//				
//		for (String a : part) {
//			
//			System.out.println(a);
//		}
//		
//		//beginning index is inclusive, end index is exclusive
//		String firstFour = s.substring(0, 4);
//		
//		System.out.println(firstFour);
//		
//		System.out.println("Last 4: " + StringExercises.lastFour(s));
//		
//		System.out.println("Last 2: " + StringExercises.lastN(s, 2));
//		
//		System.out.println();
//		
//		System.out.println("Now testing List Exercise.");
    
	}
}
