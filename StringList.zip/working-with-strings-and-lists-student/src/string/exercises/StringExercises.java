/*
 * Copyright 2017 Marc Liberatore.
 */

package string.exercises;
import list.exercises.*;

public class StringExercises {
	
	/**
	 * Searches for "Marc" in a string.
	 * 
	 * @param string a non-null string
	 * @return the index of the first occurrence of "Marc" in string, or -1 if not found
	 */
	//DO NOT USE LOOP
	public static int findMarc(String string) {
	
		int lengthOfMarc = 4;
		int index = -1;
		
		//if the length of the string is less than 4, there is no MARC present
		if (string.length() < lengthOfMarc) {
			
			return index;
		}
		
		//get the index where MARC first appears
		index = string.indexOf("Marc");
		
		//return either index of M or return -1
		return index;
	}

	/**
	 * Searches for a substring within a string.
	 * @param string a non-null string
	 * @param substring a non-null string
	 * @return the index of the first occurrence of the substring within the string, or -1 if not found
	 */
	//DO NOT USE LOOP
	public static int findSubstring(String string, String substring) {
		
		int index = -1;
		
		//if length of the substring is greater than the length of the string
		//then the substring is not present
		if (substring.length() > string.length()) {
			
			return index;
		}
		
		//get the index where the substring first appears, this function 
		//will return -1 if not found
		index = string.indexOf(substring);
		
		return index;
	}
		
	/**
	 * Returns true if and only if the string contains the substring.
	 * @param string a non-null string
	 * @param substring a non-null string
	 * @return true if and only if the string contains the substring
	 */
	//DO NOT USE LOOP
	public static boolean contains(String string, String substring) {
	
		boolean exist = false;
		
		//no chance of finding substring
		if (substring.length() > string.length()) {
			
			return exist;
		}
		
		//if we do not get -1, then the substring exists
		if (string.indexOf(substring) != -1) {
			
			//set to true
			exist = true;
		}
		
		return exist;
	}
	
	/**
	 * Splits a string into words, using whitespace to delimit the words.
	 * 
	 * See the assignment writeup for the magic argument to split().
	 * 
	 * @param string a non-null string
	 * @return an array representing the words in the string.
	 */
	//DO NOT USE LOOP
	public static String[] splitIntoWords(String string) {
		
		return string.split("\\s+");
	}
	
	/**
	 * Returns the substring representing the first four characters of the string.
	 * @param string a non-null string of length >= 4
	 * @return the substring representing the first four characters of the string
	 */
	//DO NOT USE LOOP
	public static String firstFour(String string) {
		
		return string.substring(0, 4);
	}

	/**
	 * Returns the substring representing the first n characters of the string.
	 * @param string a non-null string of length >= n
	 * @param n an integer >= 0
	 * @return the substring representing the first n characters of the string
	 */
	//DO NOT USE LOOP
	public static String firstN(String string, int n) {
		
		return string.substring(0, n);
	}
	
	/**
	 * Returns the substring representing the last four characters of the string.
	 * @param string a non-null string of length >= 4
	 * @return the substring representing the last four characters of the string
	 */
	//DO NOT USE LOOP
	public static String lastFour(String string) {
		
		return string.substring(string.length() - 4);
	}

	/**
	 * Returns the substring representing the last n characters of the string.
	 * @param string a non-null string of length >= n
	 * @param n an integer >= 0
	 * @return the substring representing the last n characters of the string
	 */
	//DO NOT USE LOOP
	public static String lastN(String string, int n) {
		
		return string.substring(string.length() - n);
	}
}
