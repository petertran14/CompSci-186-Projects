package log;

import log.LogParser;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;

public class TestMain {
	
	public static void main(String[] args) throws IOException {
		
		List<SuspectEntry> list = new ArrayList<>();
		String marcLine = "Marc,413-545-3061,1234567890";
		String garrettLine = "Garrett,(413) 545-1985,A72983752";
		String markLine = "Mark,413 545 2744,1234567890";
		String peterLine = "Peter,85-300-9842,1234567890";
		
		list = LogParser.findCommonEntries(
				Arrays.asList(
						LogParser.parseLog(new FileReader("test" + File.separator + "log" + File.separator + "data0.csv")),
						LogParser.parseLog(new FileReader("test" + File.separator + "log" + File.separator + "data1.csv")),
						LogParser.parseLog(new FileReader("test" + File.separator + "log" + File.separator + "data2.csv")),
						LogParser.parseLog(new FileReader("test" + File.separator + "log" + File.separator + "data3.csv")),
						LogParser.parseLog(new FileReader("test" + File.separator + "log" + File.separator + "data4.csv"))));
		
		System.out.println("List Size: " + list.size());
		
		for (int i = 0; i < list.size(); i++) {
			
			System.out.println(list.get(i).toString());
		}
		
//		String CSandiego = ("C. Sandiego,(101) 117-0787,1128946472366");
//		String CarmenSDiego = ("Carmen S. Diego,+1 222 345 6789,1128946472366");
//		String CarmenSanDiego = ("Carmen Sandiego,(888)007-0787x267,1128946472366");
//		String ColonelSanders = ("Colonel Sanders,1-800-CALL-KFC,1128946472366");
//		String LaMulana = ("La Mulana,762-812-4698,1128946472366");
//		
//		list = LogParser.findCommonEntries(
//				Arrays.asList(
//						LogParser.parseLog(new StringReader(CSandiego)),
//						LogParser.parseLog(new StringReader(CarmenSDiego + "\n" + marcLine)),
//						LogParser.parseLog(new StringReader(CarmenSanDiego + "\n" + marcLine)),
//						LogParser.parseLog(new StringReader(ColonelSanders + "\n" + marcLine)),
//						LogParser.parseLog(new StringReader(LaMulana))));
////		
//		System.out.println("List Size: " + list.size());
////		
//		for (int i = 0; i < list.size(); i++) {
//			
//			System.out.println(list.get(i).toString());
//		}
		
//		LogParser.findCommonEntries(
//				Arrays.asList(
//						LogParser.parseLog(new StringReader(marcLine)),
//						LogParser.parseLog(new StringReader(markLine))));
		
		
//		list = LogParser.findCommonEntries(
//				
//				//Views as "List<List<SuspectEntry>>"
//				Arrays.asList(
//						
//						//Returns List<SuspectEntry>, element at array 0
//						LogParser.parseLog(new StringReader(marcLine)),
//						
//						//Returns List<SuspectEntry>, element at array 1
//						LogParser.parseLog(new StringReader(garrettLine + "\n" + marcLine))));
//		
//		System.out.println("List Size: " + list.size());
		
//		for (int i = 0; i < list.size(); i++) {
//			
//			System.out.println(list.get(i).toString());
//		}
		
//		
//		//List<List<SuspectEntry>> bigList = Arrays.asList(LogParser.parseLog(new StringReader(marcLine + "\n" + garrettLine)));
//		//list = LogParser.parseLog(new StringReader(marcLine + "\n" + garrettLine));
//		
//		List<List<SuspectEntry>> bigList =  Arrays.asList(
//				LogParser.parseLog(new StringReader(markLine + "\n" + marcLine)),
//				LogParser.parseLog(new StringReader(marcLine)));
//		
//		System.out.println("Big List Size: " + bigList.size());
//		System.out.println("Little List Size: " + bigList.get(0).size());
//		
//		System.out.println("Display: ");
//		for (int i = 0; i < list.size(); i++) {
//			
//			System.out.println(list.get(i).toString());
//		}
		
//		SuspectEntry num1 = new SuspectEntry("Mark" , "805-300-9842", "12345");
//		SuspectEntry num2 = new SuspectEntry("Peter", "510-566-1535", "98765");
		
//		list.add(new SuspectEntry("Mark" , "805-300-9842", "12345"));
//		list.add(new SuspectEntry("Peter", "510-566-1535", "98765"));
//		
//		list.add(num1);
//		list.add(num2);
//		
//		System.out.println("Display: ");
//		for (int i = 0; i < list.size(); i++) {
//			
//			System.out.println(list.get(i).toString());
//		}
		
//		String marcLine = "Marc,413-545-3061,1234567890";
//		list = LogParser.parseLog(new StringReader(marcLine));
		
//		System.out.println("Display: ");
//		for (int i = 0; i < list.size(); i++) {
//			
//			System.out.println(list.get(i).toString());
//		}
//		
//		String[] names = {"Larry", "Moe", "Curly"};
//		List<String> stooges = Arrays.asList(names);
//		System.out.println(stooges);
//		
//		//the return value looks like a list, but is really supported by an array
//		//arrays have a fixed size and we cannot treat them like dynamic interfaces like lists
//		stooges.add("fun");
//		System.out.println(stooges);
		
//		List<String> myList = new ArrayList<String>();
//		myList.add("Apple");
//		myList.add("Banana");
//		myList.add("Orange");
//		String[] myArray = myList.toArray(new String[0]);
//		for (String myString : myArray) {
//		   System.out.println(myString);
//		}
//		SuspectEntry marc = new SuspectEntry("Marc", "413-545-3061", "1234567890");
//		List<SuspectEntry> foo = Arrays.asList(marc);
//		
//		for (int i = 0; i < foo.size(); i++) {
//			
//			System.out.println(foo.get(i).toString());
//		}
//		
//		System.out.println();
//		System.out.println();
//		for (int i = 0; i < list.size(); i++) {
//			
//			System.out.println(list.get(i).toString());
//		}
//		
//		if (foo.equals(list)) {
//			
//			System.out.println("Equals");
//		}
//		
//		else {
//			
//			System.out.println("Not Equals");
//		}
	}
}
