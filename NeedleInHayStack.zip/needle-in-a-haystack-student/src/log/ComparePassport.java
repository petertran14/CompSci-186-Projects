package log;

import java.util.Comparator;

public class ComparePassport implements Comparator<SuspectEntry> {

	@Override
	public int compare(SuspectEntry o1, SuspectEntry o2) {
		
		if (o1.getPassportNumber().compareTo(o2.getPassportNumber()) < 0) {
			
			return -1;
		}
		
		if (o1.getPassportNumber().compareTo(o2.getPassportNumber()) > 0) {
			
			return 1;
		}
		
		//passport numbers are the same
		if (o1.getPassportNumber().compareTo(o2.getPassportNumber()) == 0) {
			
			//break ties by name
			if (o1.getName().compareTo(o2.getName()) < 0) {
				
				return -1;
			}
			
			if (o1.getName().compareTo(o2.getName()) > 0) {
				
				return 1;
			}
			
			if (o1.getName().compareTo(o2.getName()) == 0) {
				
				//break ties by phone number
				if (o1.getPhoneNumber().compareTo(o2.getPhoneNumber()) < 0) {
					
					return -1;
				}
				
				if (o1.getPhoneNumber().compareTo(o2.getPhoneNumber()) > 0) {
					
					return 1;
				}
			}
		}
		
		return 0;
	}
}
