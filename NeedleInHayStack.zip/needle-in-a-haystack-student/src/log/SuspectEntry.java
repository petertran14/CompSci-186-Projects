/*
 * Copyright 2017 Marc Liberatore.
 */

package log;

import java.io.IOException;
import java.util.List;
import java.util.Set;

public class SuspectEntry {
	
	private String name;
	private String phoneNumber;
	private String passportNumber;
	
	public SuspectEntry(String name, String phoneNumber, String passportNumber) {
		
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.passportNumber = passportNumber;
	}
	/**
	 * Returns the name of the suspect
	 * 
	 * @return String
	 */
	public String getName() {
		
		return this.name;
	}
	
	/**
	 * Returns the phone number of the suspect
	 * 
	 * @return String
	 */
	public String getPhoneNumber() {
		
		return this.phoneNumber;
	}
	
	/**
	 * Returns the passport number of the suspect
	 * 
	 * @return String
	 */
	public String getPassportNumber() {
		
		return this.passportNumber;
	}
	
	/**
	 * Returns true of false whether or not the two SuspectEntries are identical
	 * 
	 * @param SuspectEntry
	 * @return boolean
	 */
	public boolean isIdentical(SuspectEntry other) {
		
		return this.equals(other);
	}
	
	/**
	 * Returns true of false whether or not the two SuspectEntries are aliases
	 * 
	 * Checks if the two suspects are aliases
	 * 	-they have tried to be sneaky by having a different phone and/or name
	 * 
	 * @param SuspectEntry
	 * @return boolean
	 */
	public boolean isAlias(SuspectEntry other) {
		
		//if the passport numbers match but either the phone and/or name is different
		if (this.getPassportNumber() == other.getPassportNumber() &&
		   (this.getName() != other.getName() && this.getPhoneNumber() == other.getPhoneNumber()) ||
		   (this.getName() == other.getName() && this.getPhoneNumber()!= other.getPhoneNumber()) ||
		   (this.getName() != other.getName() && this.getPhoneNumber() != other.getPhoneNumber())) {
		   
			return true;
		}
	
		return false;
	}
	
	/**
	 * Returns an object of the SuspectList class 
	 * 
	 * Searches the buffer of Suspects to find the suspect that contains the passport of interest and return it
	 * 
	 * @param SuspectEntry
	 * @return SuspectEntry
	 */
	public SuspectEntry searchPassport(List<SuspectEntry> buffer) {
		
		boolean found = false;
		int index = 0;
		
		//loop through the buffer
		for (int i = 0; i < buffer.size() && !found; i++) {
			
			if (buffer.get(i).getPassportNumber().equals(this.getPassportNumber())) {
				
				 //caught the object in the buffer that has the same passport as our arg
				 found = true;
				 index = i;
			}
		}
		
		return buffer.get(index);	
	}
	
	/**
	 * Returns a string of the member variables of this class.
	 * 
	 * Allows us to see the suspect name, phone and passport number.
	 * 
	 * Marc,413-545-3061,1234567890
	 * 
	 * representing a name, phone number, and passport number.
	 * 
	 * 
	 * @return a string
	 * 
	 */
	public String toString() {
		
		return (this.name + "\n" + this.phoneNumber + "\n" + this.passportNumber);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((passportNumber == null) ? 0 : passportNumber.hashCode());
		result = prime * result + ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
		return result;
	}

	//Very important method here.
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SuspectEntry other = (SuspectEntry) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (passportNumber == null) {
			if (other.passportNumber != null)
				return false;
		} else if (!passportNumber.equals(other.passportNumber))
			return false;
		if (phoneNumber == null) {
			if (other.phoneNumber != null)
				return false;
		} else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		return true;
	}
}
