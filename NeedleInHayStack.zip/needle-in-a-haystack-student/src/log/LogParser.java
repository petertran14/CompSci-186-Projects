/*
 * Copyright 2017 Marc Liberatore.
 */

package log;


import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import log.ComparePassport;

import com.opencsv.CSVReader;

public class LogParser {	
	/**
	 * Returns a list of SuspectEntries corresponding to the CSV data supplied by the given Reader.
	 * 
	 * The data contains one or more lines of the format:
	 * 
	 * Marc,413-545-3061,1234567890
	 * 
	 * representing a name, phone number, and passport number.
	 * 
	 * @param r an open Reader object
	 * @return a list of SuspectEntries
	 * @throws IOException
	 */
	
	/*
	 * 1. Use the Reader to get all the info from the csv into a String[]
	 * 2. Somehow use the info stored in String[] and pass it to the SuspectEntry class
	 * 3. Return a List of SuspectEntry classes
	 */
	public static List<SuspectEntry> parseLog(Reader r) throws IOException {
		
		//a list of potential thieves
		List<SuspectEntry> listOfCriminals = new ArrayList<>();
		
		try {
			
			//instantiate the Reader obj
			//attempt to read from the file, if there is an error control will 
			//pass to the catch clause
			CSVReader reader = new CSVReader(r);
			int quantityOfInfo = 3;
			
			//load the info from the csv into a list of String[]'s
			List<String[]> suspectInfo = reader.readAll();
			
			//close the input file
			reader.close();
			
			//load the info in the List to the SuspectEntry class
			for (int i = 0; i < suspectInfo.size(); i++) {
				
				//local variables to temporarily hold values
				String name = "";
				String phone = "";
				String pass = "";
				
				//each String[] holds 3 tokens of info we need
				for (int info = 0; info < quantityOfInfo; info++) {
					
					//store the name
					if (info == 0) {
						
						name = suspectInfo.get(i)[info];
					}
					
					//store the phone number
					if (info == 1) {
						
						phone = suspectInfo.get(i)[info];
					}
					
					//store the passport number
					if (info == 2) {
						
						pass = suspectInfo.get(i)[info];
					}
				}
				
				//add to the list of potential criminals
				listOfCriminals.add(new SuspectEntry(name, phone, pass));
			}
			
		} catch (IOException e) {
			
			throw new IOException();
		}
		
		//The code passes a SuspectEntry array with length 0. 
		//Since the elements will not fit, a new Array is created and returned to the caller.
		SuspectEntry[] array = listOfCriminals.toArray(new SuspectEntry[0]);
		
		//change the "view" of the array to a list backed by the array. This list has fixed size and is immutable.
		List<SuspectEntry> fixedList = Arrays.asList(array);
		
		return fixedList; 
	}
	/**
	 * Returns a sorted list of SuspectEntries whose passport numbers are common to all 
	 * of the supplied entryLists.
	 * 
	 * The list is sorted lexicographically by passport number, breaking ties by name 
	 * and then by phone number.
	 * 
	 * @param entryLists a list of lists of SuspectEntries
	 * @return a sorted list of SuspectEntries whose passport numbers are common to all 
	 * of the supplied entryLists
	 */
	
	/*
	 * Returns a sorted list of repeat passport among the list of lists.
	 * 
	 * For example, two entries may have the same passport number but different phone or name
	 * 	- Both entries are returned in the list
	 * 	- Sorted first by name, then by phone number
	 * 
	 * Two or more entries are identical
	 * 	- One instance of the identical entries is added to the list
	 */
	
	/*
	 * Returns the Suspects who's passport numbers appear in each BigList
	 */

	public static List<SuspectEntry> findCommonEntries(List<List<SuspectEntry>> entryLists) {
		
		List<SuspectEntry> match = new ArrayList<>();
		
		//if the list of suspects is empty
		if (entryLists.isEmpty()) {
			
			return match;
		}
		
		//if the entryLists has only one BigList and within it, only one SmallList
		if (entryLists.size() == 1) {
			
			//loop for the size of the list inside the big list
			for (int i = 0; i < entryLists.get(0).size(); i++) {
			
				//add all the elements in the little list to the matching list since there is only one suspect.
				match.add(entryLists.get(0).get(i));
			}
			
			return match;
		}
		
		//this keeps a tally of all the unique suspects
		List<SuspectEntry> buffer = new ArrayList<>();
		List<String> passportList = new ArrayList<>();
		
		//loop for the outer list
		for (int outer = 0; outer < entryLists.size(); outer++) {
			
			//loop for the inner list
			for (int inner = 0; inner < entryLists.get(outer).size(); inner++) {
				
				//if the buffer does not contain the element with the current passport number, add it
				if (!passportList.contains(entryLists.get(outer).get(inner).getPassportNumber())) {
					
					//add the element to the list
					buffer.add(entryLists.get(outer).get(inner));
					
					//add the passport num to the list
					passportList.add(entryLists.get(outer).get(inner).getPassportNumber());
				}
				
				//the buffer does have the passport number already
				else {
					
					//check if the objects are identical by searching for the object in the buffer, and
					//returning the object that was first stored
					SuspectEntry compare = entryLists.get(outer).get(inner).searchPassport(buffer);
					
					//if they are identical, add it once, but never add it again
					if (compare.isIdentical(entryLists.get(outer).get(inner)) && !match.contains(compare)) {
						
						match.add(compare);
					}
					
					//they are aliases, same passport number, different name and/or phone
					else if (compare.isAlias(entryLists.get(outer).get(inner))) {
						
						//add both unless they already exist
						if (!match.contains(entryLists.get(outer).get(inner))) {
							
							match.add(entryLists.get(outer).get(inner));
						}
						
						if (!match.contains(compare)) {
							
							match.add(compare);
						}
					}
				}
			}
		}
		
		//narrow the match list down, so that it contains only suspects from EACH Big List
		match = commonSuspects(entryLists, match);
		
		//sort
		match.sort(new ComparePassport());
		
		return match;
	}
	
	
	/**
	 * Returns a list of suspects that appear in all the big logs
	 * 
	 * @param logs
	 * @param list
	 * @return narrow, a list of suspects
	 */
	
	//This needs to identify based on identical passport number, NOT equal objects
	public static List<SuspectEntry> commonSuspects(List<List<SuspectEntry>> logs, List<SuspectEntry> list) {
		
		//this list should only hold objects that have the same passport number
		List<SuspectEntry> narrow = new ArrayList<>();
		boolean found = false;
		int outerFound = 0;
		
		//compare one item in our list to the logs, one at a time
		for (int scan = 0; scan < list.size(); scan++) {
			
			//reset 
			outerFound = 0;
	
			//loop through List<List<SuspectEntry>>
			for (int outer = 0; outer < logs.size(); outer++) {
				
				//reset
				found = false;
				
				//loop through List<SuspectEntry> to individual objects
				for (int inner = 0; inner < logs.get(outer).size(); inner++) {
					
					//does the log have the passport number of our list
					if (list.get(scan).getPassportNumber().equals(logs.get(outer).get(inner).getPassportNumber())) {
						
						found = true;
					}
				}
				
				//if the passport number of the object was present in the small list
				if (found) {
					
					//increment
					outerFound++;
				}
			}
			
			//if the passport number was present in all the big lists
			if (outerFound == logs.size()) {
				
				//add it to our collection
				narrow.add(list.get(scan));
			}
		}
		
		return narrow;
	}
}
