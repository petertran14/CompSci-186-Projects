/*
 * Copyright 2017 Marc Liberatore.
 */

package mosaic;

import java.awt.image.BufferedImage;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import images.ImageUtils;

public class TileFactory {
	public final int tileWidth;
	public final int tileHeight;
	// TODO: you will NOT be keeping this array in your final code; 
	// see assignment description for details
	//private final int[] hues;
	
	//The keys are integers that represent the hues of color and the
	//the values are pieces of images that have RGB values that are closely linked to
	//a hue(integer).
	
	private final Map<Integer, List<BufferedImage>> hues;
	
	/**
	 * 
	 * @param colors the palette of RGB colors for this TileFactory
	 * @param tileWidth width (in pixels) for each tile
	 * @param tileHeight height (in pixels) for each tile
	 */
	public TileFactory(int[] colors, int tileWidth, int tileHeight) {
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
		// TODO: when you replace the int[] hues, be sure to replace this code, as well
		
		//created a new instance of map
		hues = new HashMap<Integer, List<BufferedImage>>();
		
		//colors[] can be converted to the keys, put them in the map
		for (int i = 0; i < colors.length; i++) {
			
			//keys are the colors after they have been converted, and the values of the keys are empty arrays for now
			hues.put(Math.round(ImageUtils.hue(colors[i])), new ArrayList<BufferedImage>());
		}
	}
	
	/**
	 * Returns the distance between two hues on the circle [0,256).
	 * 
	 * @param hue1 
	 * @param hue2
	 * @return the distance between two hues.
	 */
	static int hueDistance(int hue1, int hue2) {
		// TODO
		
		//holds the distance between the two hues
		int distance = 0;
		
		//if both colors are the same
		if (hue1 == hue2) {
			
			return distance;
		}
		
		//find the largest and smallest of the two int
		int bigHue = Math.max(hue1, hue2);
		int smallHue = Math.min(hue1, hue2);
		
		//intervals to help facilitate the logic
		int maxVal = 255;
		int middleValue = 153;
		
		//if (hue1 - hue2) > 153(middle value) since 0 is inclusive
		if ((bigHue - smallHue) > middleValue) {
			
			//then we cannot just use abs(a-b), we must take
			//(max val - bigger hue) + (smaller hue + 1)
			//we added one to the smaller hue to account for the fact
			//that 0 is inclusive in our interval
			distance = (maxVal - bigHue) + (smallHue + 1);
		
		}
		//else, we can use the abs(a-b)
		else {
			
			distance = (bigHue - smallHue);
		}
		
		return distance;
	}
	
	/**
	 * Returns the closest hue from the fixed palette this TileFactory contains.
	 * 
	 * If the distance of the input hue is the same for any keys, break ties by choosing the smaller keyHue
	 * 
	 * @param hue
	 * @return the closest hue from the palette
	 */
	Integer closestHue(int hue) {
		// TODO
		
		int count = 0;
		int closest = 0;
		int minDistance = 0;
		
		//compare the hue against each hue in the palette(map)
		for (Integer key : this.hues.keySet()) {
			
			//if we have found a closer match or its the first try
			if (TileFactory.hueDistance(key, hue) < minDistance || count == 0) {
				
				//set the minDistance
				minDistance = TileFactory.hueDistance(key, hue);
				closest = key;
			}
			
			//break the ties
			else if (TileFactory.hueDistance(key, hue) == minDistance) {
				
				//choose the hueKey with the smallest num
				closest = Math.min(key, closest); 
			}
			
			//increment
			count++;
		}
		
		return closest;
	}
	
	/**
	 * Adds an image to this TileFactory for later use.
	 * @param image the image to add
	 */
	public void addImage(BufferedImage image) {
		
		image = ImageUtils.resize(image, tileWidth, tileHeight);
				
		int avgHue = ImageUtils.averageHue(image);
		
		// TODO: add the image to the appropriate place in your map from hues to lists of images
		
		//the closestHue method will return the key that the image is associated with
		int keyToAdd = closestHue(avgHue);
		
		//list is pointing to the List in the key. Any changes in list
		//will directly affect our multimap.
		List<BufferedImage> list = this.hues.get(keyToAdd);
		
		//add the targetImage to the list of bufferedImages
		list.add(image);
	}
	
	/**
	 * Returns the next tile from the list associated with the hue most closely matching the input hue.
	 * 
	 * The returned values should cycle through the list. Each time this method is called, the next 
	 * tile in the list will be returned; when the end of the list is reached, the cycle starts over.
	 *  
	 * @param hue the color to match
	 * @return a tile matching hue
	 */
	public BufferedImage getTile(int hue) {
		// TODO:  return an appropriate image from your map of hues to lists of images; 
		// see assignment description for details
		
		//key that most closely resembles the imput hue
		int hueKey = closestHue(hue);
		int rotate = 0;
		
		//retrieve the list of images associated to the hue
		List<BufferedImage> listOfImages = this.hues.get(hueKey);
		
		//get the image at position 0, each time there will be a different image at the front
		BufferedImage image = listOfImages.get(rotate);
		
		//After calling this method, the element at index i will be 
		//the element previously at index (i - distance) mod list.size()
		Collections.rotate(listOfImages, -1);
		
		return image;
	}
}
