package images;

import mosaic.TileFactory;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class TestDriver {

	public static void main(String[] args) {
		
		int hue1 = 151;
		int hue2 = 153;
		
		//change hueDistance back to default when done
		//int distance = TileFactory.hueDistance(hue1, hue2);
		
		//System.out.println(distance);
		
		List<Integer> list = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			
			list.add(i);
		}
		
		System.out.println("Before: ");
		
		for (Integer item : list) {
			
			System.out.print(item);
		}
		
		Collections.rotate(list, -1);
		
		System.out.println();
		System.out.println("After: ");
		
		for (Integer item : list) {
			
			System.out.print(item);
		}
	}
}
