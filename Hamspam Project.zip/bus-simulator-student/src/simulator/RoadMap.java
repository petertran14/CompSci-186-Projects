/*
 * Copyright 2017 Marc Liberatore.
 */

package simulator;

/**
 * A map of road(s), where each cell is numbered with an x and y coordinate. The
 * north-western-most corner is at location(0,0). Moving south means increasing
 * the y value; moving east means increasing the x value. Each cell either is or
 * is not a road.
 * 
 * @author liberato
 *
 */
public class RoadMap {
	public final int xSize;
	public final int ySize;
	private final boolean[][] isRoad;

	public RoadMap(int x, int y) {
		isRoad = new boolean[x][y];
		xSize = x;
		ySize = y;
	}

	/**
	 * Use this method to create a RoadMap from a String. Use 'X' for non-road and
	 * '.' for road.
	 * 
	 * For example, the string
	 * 
	 * "XXX 
	 *  X.. 
	 *  X.X"
	 * 
	 * (including whitespace!) creates a 3x3 map, where there is a short road
	 * that travels north from the center of the bottom of the map, and then
	 * turns east to the center of the right-hand side of the map.
	 * 
	 * @param s a string representing a map of roads
	 * @return a new RoadMap instance
	 */
	public static RoadMap fromString(String s) {
		String[] lines = s.trim().split("\\s+");
		final int xSize = lines[0].length();
		final int ySize = lines.length;

		RoadMap roadMap = new RoadMap(xSize, ySize);
		for (int y = 0; y < ySize; y++) {
			for (int x = 0; x < xSize; x++) {
				if (lines[y].charAt(x) == '.') {
					roadMap.isRoad[x][y] = true;
				}
			}
		}

		return roadMap;
	}

	//uses the information of the map to convert into "XXX...XXX" symbols
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int y = 0; y < ySize; y++) {
			for (int x = 0; x < xSize; x++) {
				if (isRoad[x][y]) {
					sb.append('.');
				} else {
					sb.append('X');
				}
			}
			sb.append('\n');
		}
		return sb.substring(0, sb.length() - 1);
	}
	
	//returns ySize
	public int getYSize() {
		
		return this.ySize;
	}
	
	//returns xSize
	public int getXSize() {
		
		return this.xSize;
	}

	//checks whether the particular point is a road
	public boolean isRoad(int x, int y) {
		
		return isRoad[x][y];
	}

	//can set a part of the map to be a road or to not be a road
	public void setRoad(int x, int y, boolean isRoad) {
		this.isRoad[x][y] = isRoad;
	}

	public boolean NorthRoad(int x, int y) {
		
		//check if the road we are about to return is out of bounds
		if (this.boundsCheck(x, y - 1, "NORTH")) {
		
			return this.isRoad(x, y - 1);
		}
		
		//do not even check the road if it is off the map, to prevent outOfBoundException
			
		return false;
	}
	
	public boolean SouthRoad(int x, int y) {
		
		//check bounds
		if (this.boundsCheck(x, y + 1, "SOUTH")) {
		
			return this.isRoad(x, y + 1);
		}
			
		return false;
	}
	
	public boolean EastRoad(int x, int y) {
		
		//check bounds
		if (this.boundsCheck(x + 1, y, "EAST")) {
		
			return this.isRoad(x + 1, y);
		}
		
		return false;
	}
	
	//pass in direction to bounds check
	public boolean WestRoad(int x, int y) {
		
		//check bounds
		if (this.boundsCheck(x - 1, y, "WEST")) {
		
			return this.isRoad(x - 1, y);
		}
		
		return false;
	}
	
	public boolean adjacentRoad(int x, int y, String d) {
		
		if (d == "NORTH") {
			
			//check bounds
			if (this.boundsCheck(x, y - 1, d)) {
			
				return this.isRoad(x, y - 1);
			}
			
			return false;
		}
		
		else if (d == "SOUTH") {
			
			//check bounds
			if (this.boundsCheck(x, y + 1, d)) {
			
				return this.isRoad(x, y + 1);
			}
			
			return false;
		}
		
		else if (d == "WEST") {
			
			//check bounds
			if (this.boundsCheck(x - 1, y, d)) {
				
				return this.isRoad(x - 1, y);
			}
			
			return false;
		}
		
		//east
		else {
			
			//check bounds
			if (this.boundsCheck(x + 1, y, d)) {
			
				return this.isRoad(x + 1, y);
			}
			
			return false;
		}
	}
	
	public boolean boundsCheck(int x, int y, String d) {
		
		//if the 0 < x > 9 and 0 < y > 9, then we have serious issues
		//need getters that return the size of the map
		
		if ((d == "NORTH" || d == "SOUTH") && (y > this.getYSize() - 1 || y < 0)) {
			
			return false;
		}
		
		//check east and west
		else if ((d == "EAST" || d == "WEST") && (x > this.getXSize() -1 || x < 0)) {
			
			return false;
		}
		
		//we are all good
		return true;
	}
}
