/*
 * Copyright 2017 Marc Liberatore.
 */

package simulator;

public class Bus {
	public final int number;
	private final RoadMap roadMap;
	
	//my own additions
	private boolean exist = false;
	private boolean success = true;
	
	private int x;
	private int y;
	private String direction;

	public Bus(int number, RoadMap roadMap, int x, int y) {
		this.number = number;
		this.roadMap = roadMap;
		this.x = x;
		this.y = y;

	}
	
	//sets the direction
	public void setDirection(String s) {
		
		this.direction = s;
	}
	
	//gets the direction
	public String getDirection() {
		
		return this.direction;
	}
	
	//sets a new x coordinate
	public void setX(int x) {
		
		this.x = x;
	}
	
	//sets a new y coordinate
	public void setY(int y) {
		
		this.y = y;
	}

	//gets the x coordinate
	public int getX() {
		return x;
	}

	//gets the y coordinate
	public int getY() {
		return y;
	}
	

	/**
	 * Move the bus. Buses only move along the cardinal directions
	 * (north/south/east/west), not diagonally.
	 * 
	 * If the bus is stopped (that is, if it was just placed, or if it didn't
	 * move last time move() was called), then it should attempt to move north.
	 * If it cannot (no road, or off the map), then it should attempt south,
	 * then east, then west. If no move is available, it should stay in its
	 * current position.
	 * 
	 * If the bus is moving (that is, if it successfully moved the last time
	 * move() was called), then it should attempt to continue moving in the same
	 * direction.
	 * 
	 * If it cannot (no road, or off the map), then it should attempt to turn
	 * right. For example, if the bus was moving north, but there is no more
	 * road to the north, it should move east if possible.
	 * 
	 * If it cannot turn right, it should turn left. If it cannot turn left, it
	 * should reverse direction (that is, move backward, if possible). 
	 * If it cannot do any of these things, it should stay in its current position.
	 */
	public void move() {
		
		//Created a new bus, created a map, and placed it at x = 1, y = 2;
		// X.X
		// X.X
		// X.X
		//In this case, the bus has no choice but to move north
		
		//This is for the first time the bus was created, or if move was unsuccessful
		if (!this.exist || !success) {
			
			//at this point, the only way to enter this conditional
			//is if a move call was unsuccessful
			this.exist = true;
			
			//Check if North has a road
			if (this.roadMap.NorthRoad(x, y)) {
				
				//attempt to move north
				this.setY(y - 1);
				this.success = true;
				
				//remember direction
				this.setDirection("NORTH");
				
				//need to check direction
				
				/*
				 * The reason why we need to set direction here is because for the first time we call move,
				 * the control will not enter the big else statement below that checks and resets direction. Thus, our second call
				 * will attempt to change direction, but that should have already been checked and done by the first call to move.
				 */
				
				//check right if there are no more north roads
				if (this.roadMap.EastRoad(x, y) && !this.roadMap.NorthRoad(x, y)) {
					
					this.setDirection("EAST");
				}
				
				//check left
				else if (this.roadMap.WestRoad(x, y) && !this.roadMap.NorthRoad(x, y)) {
					
					this.setDirection("WEST");
				}
				
				//check backward
				else if (this.roadMap.SouthRoad(x, y) && !this.roadMap.NorthRoad(x, y)) {
					
					this.setDirection("SOUTH");
				}
				
				
			}
			
			else if (this.roadMap.SouthRoad(x, y)) {
				
				//attempt to move south
				this.setY(y + 1);
				this.success = true;
				
				//remember direction
				this.setDirection("SOUTH");
				
				//need to check direction
				//check right if there are no more South roads
				if (this.roadMap.WestRoad(x, y) && !this.roadMap.SouthRoad(x, y)) {
					
					this.setDirection("WEST");
				}
				
				//check left
				else if (this.roadMap.EastRoad(x, y) && !this.roadMap.SouthRoad(x, y)) {
					
					this.setDirection("EAST");
				}
				
				//check backwards
				else if (this.roadMap.NorthRoad(x, y) && !this.roadMap.SouthRoad(x, y)) {
					
					this.setDirection("NORTH");
				}
			}
			
			else if (this.roadMap.EastRoad(x, y)) {
				
				//attempt to move east
				this.setX(x + 1);
				this.success = true;
				
				//remember direction
				this.setDirection("EAST");
				
				//need to check direction
			
				//turn right, if there are no more East roads
				if (this.roadMap.SouthRoad(x, y) && !this.roadMap.EastRoad(x, y)) {
					
					this.setDirection("SOUTH");
				}
				
				//else, turn left
				if (this.roadMap.NorthRoad(x, y) && !this.roadMap.EastRoad(x, y)) {
					
					this.setDirection("NORTH");
				}
			}
			
			else if (this.roadMap.WestRoad(x, y)) {
				
				//attempt to move west
				this.setX(x - 1);
				this.success = true;
				
				//remember direction
				this.setDirection("WEST");
				
				//need to check direction
				//turn right, if there are no more West roads
				if (this.roadMap.NorthRoad(x, y) && !this.roadMap.WestRoad(x, y)) {
					
					this.setDirection("NORTH");
				}
				
				//else turn left
				else if (this.roadMap.SouthRoad(x, y) && !this.roadMap.WestRoad(x, y)) {
					
					this.setDirection("SOUTH");
				}
				
				//else go backwards
				else if (this.roadMap.EastRoad(x, y) && !this.roadMap.WestRoad(x, y)) {
					
					this.setDirection("EAST");
				}
			}
			
			else {
				
				//Stay in original position -> no changes on x and y
				this.success = false;
			}
		}
		
		//The bus has already attempted to move at least once,
		//and it was successful
		else {
			
			//change direction only once per entry
			int count = 0;
			
			//while there is another road that goes in the same direction
			
			
			//This throws an Exception!!!!
			while (this.roadMap.adjacentRoad(x, y, this.getDirection()) && count < 1) {
				
				//if the direction is North
				if (this.getDirection() == "NORTH") {
					
					this.setY(y - 1);
					count++;
				}
				
				//if the direction is South
				else if (this.getDirection() == "SOUTH") {
					
					this.setY(y + 1);
					count++;
				}
				
				//if the direction is West
				else if (this.getDirection() == "WEST") {
					
					this.setX(x - 1);
					count++;
				}
				
				//if the direction is East
				else {
					
					this.setX(x + 1);
					count++;
				}
			}
			
			//while there is not a road in the same direction
			while (!this.roadMap.adjacentRoad(x, y, this.getDirection()) && this.success) {
				
				//we checked all 4 directions and there are no options
				if (!this.roadMap.NorthRoad(x, y) && !this.roadMap.SouthRoad(x, y) 
					&& !this.roadMap.EastRoad(x, y) && !this.roadMap.WestRoad(x, y)) {
					
					//we are stuck in one place, this is one of the exit conditions of this loop
					this.success = false;
				}
				
				//if the direction was North, and there was no more North roads, turn right = East
				else if (this.getDirection() == "NORTH") {
					
					//check to turn right
					if (this.roadMap.EastRoad(x, y)) {
					
						this.setDirection("EAST");
					}
					
					//check to turn left
					else if (this.roadMap.WestRoad(x, y)) {
					
						this.setDirection("WEST");
					}
					
					//check to turn backwards
					else if (this.roadMap.SouthRoad(x, y)) {
					
						this.setDirection("SOUTH");
					}
				}
				
				//if the direction was South, and there was no more South roads, turn right = West
				else if (this.getDirection() == "SOUTH") {
					
					//check to turn right
					if (this.roadMap.WestRoad(x, y)) {
					
						this.setDirection("WEST");
					}
					
					//check to turn left
					else if (this.roadMap.EastRoad(x, y)) {
					
						this.setDirection("EAST");
					}
					
					//check to turn backwards
					else if (this.roadMap.NorthRoad(x, y)) {
					
						this.setDirection("NORTH");
					}
				}
				
				//if the direction was West, and there was no more West roads, turn right = North
				else if (this.getDirection() == "WEST") {
					
					//check to turn right
					if (this.roadMap.NorthRoad(x, y)) {
					
						this.setDirection("NORTH");
					}
					
					//check to turn left
					else if (this.roadMap.SouthRoad(x, y)) {
					
						this.setDirection("SOUTH");
					}
					
					//check to turn backwards
					else if (this.roadMap.EastRoad(x, y)) {
					
						this.setDirection("EAST");
					}
				}
				
				//if the direction was East, and there was no more East roads, turn right = South
				else {
					
					//check to turn right
					if (this.roadMap.SouthRoad(x, y)) {
					
						this.setDirection("SOUTH");
					}
					
					//check to turn left
					else if (this.roadMap.NorthRoad(x, y)) {
					
						this.setDirection("NORTH");
					}
					
					//check to turn backwards
					else if (this.roadMap.WestRoad(x, y)) {
						
						this.setDirection("WEST");
					}
				}
			}
		}	
	}
}
